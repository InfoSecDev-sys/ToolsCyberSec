/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        void: "#0a0a0f",
        surface: "#12121a",
        border: "#1e1e2e",
        muted: "#6b7280",
        accent: "#22c55e",
        danger: "#ef4444",
        warn: "#f59e0b",
        exploit: "#a855f7",
        vuln: "#f97316",
      },
      fontFamily: {
        mono: ["JetBrains Mono", "Fira Code", "monospace"],
      },
    },
  },
  plugins: [],
}
