import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
});

export default api;

export type Project = { id: number; name: string; description?: string };
export type Domain = { id: number; project_id: number; name: string; notes?: string; in_scope?: boolean };
export type Subdomain = { id: number; domain_id: number; name: string; status: 'up' | 'down' | 'unknown' | 'exploited' };
export type IPAddress = { id: number; subdomain_id: number; address: string; os_type?: string; icon_id?: number };
export type Port = { id: number; ip_id: number; number: number; protocol: string };
export type Service = { id: number; port_id: number; name: string; version?: string; status?: string; notes?: string };
export type User = { id: number; subdomain_id: number; username: string; email?: string; notes?: string };
export type CVE = { id: number; subdomain_id: number; cve_id: string; severity?: string; description?: string };
export type Note = { id: number; content: string; tags?: string; project_id?: number; domain_id?: number; subdomain_id?: number };
export type DashboardStats = {
  total_domains: number;
  total_subdomains: number;
  alive_subdomains: number;
  dead_subdomains: number;
  total_ips: number;
  total_ports: number;
  total_services: number;
  total_vulnerabilities: number;
  exploited_services: number;
  recon_progress_pct: number;
  enumeration_progress_pct: number;
  exploitation_progress_pct: number;
};
export type GraphNode = { id: string; type: string; label: string; status?: string; data?: Record<string, unknown> };
export type GraphEdge = { id: string; source: string; target: string };
export type GraphResponse = { nodes: GraphNode[]; edges: GraphEdge[] };
