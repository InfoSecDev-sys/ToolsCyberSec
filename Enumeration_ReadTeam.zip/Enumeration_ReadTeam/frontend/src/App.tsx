import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Layout from './components/Layout';
import ProjectList from './pages/ProjectList';
import Dashboard from './pages/Dashboard';
import GraphView from './pages/GraphView';
import DataEntry from './pages/DataEntry';
import ImportExport from './pages/ImportExport';
import Login from './pages/Login';

function AppRoutes() {
  const { isProtected, isAuthenticated, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-void">
        <div className="text-muted">Loading...</div>
      </div>
    );
  }
  if (isProtected && !isAuthenticated) {
    return <Login />;
  }
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<ProjectList />} />
        <Route path="project/:projectId" element={<Dashboard />} />
        <Route path="project/:projectId/graph" element={<GraphView />} />
        <Route path="project/:projectId/entry" element={<DataEntry />} />
        <Route path="project/:projectId/import" element={<ImportExport />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
