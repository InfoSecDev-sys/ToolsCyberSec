import { memo } from 'react';
import { Handle, type NodeProps, Position } from '@xyflow/react';
import { Copy, ExternalLink } from 'lucide-react';

const OS_ICON_NAMES = ['windows', 'windows_server', 'linux', 'ubuntu', 'kali', 'macos', 'network_device', 'unknown'];

function OsIcon({ osType }: { osType: string }) {
  const name = OS_ICON_NAMES.includes(osType) ? osType : 'unknown';
  return (
    <img
      src={`/os-icons/${name}.svg`}
      alt=""
      className="w-3.5 h-3.5 shrink-0 opacity-90"
    />
  );
}

function GraphNodeComponent({ data, id }: NodeProps) {
  const label = (data?.label as string) ?? '';
  const type = (data?.type as string) ?? '';
  const copyText = (data?.copyText as string) ?? label;
  const linkUrl = data?.linkUrl as string | undefined;
  const osType = (data?.os_type as string) ?? 'unknown';
  const status = data?.status as string | undefined;

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(copyText);
  };

  const handleOpen = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (linkUrl) window.open(linkUrl, '_blank');
  };

  const showOsIcon = type === 'ip';

  return (
    <div className="rounded border border-white/20 overflow-hidden min-w-[100px]">
      <Handle type="target" position={Position.Left} className="!w-2 !h-2 !border-2" />
      <div className="flex items-center gap-1.5 px-2 py-1.5">
        {showOsIcon && <OsIcon osType={osType} />}
        <span className="text-xs font-medium truncate max-w-[120px]" title={label}>
          {label}
        </span>
        {status && (
          <span className={`text-[10px] shrink-0 ${status === 'up' ? 'text-green-400' : status === 'down' ? 'text-red-400' : status === 'exploited' ? 'text-purple-400' : 'text-gray-500'}`}>
            {status}
          </span>
        )}
        <div className="flex items-center gap-0.5 shrink-0 ml-auto">
          <button
            type="button"
            onClick={handleCopy}
            className="p-0.5 rounded hover:bg-white/20 text-gray-400 hover:text-white"
            title="Copy"
          >
            <Copy size={12} />
          </button>
          {linkUrl && (
            <button
              type="button"
              onClick={handleOpen}
              className="p-0.5 rounded hover:bg-white/20 text-gray-400 hover:text-white"
              title="Open in browser"
            >
              <ExternalLink size={12} />
            </button>
          )}
        </div>
      </div>
      <Handle type="source" position={Position.Right} className="!w-2 !h-2 !border-2" />
    </div>
  );
}

export default memo(GraphNodeComponent);
