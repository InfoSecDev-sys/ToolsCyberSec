import { Link, useParams } from 'react-router-dom';
import { LayoutDashboard, GitBranch, PenLine, FileInput, Home, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function Sidebar() {
  const { projectId } = useParams();
  const { isProtected, logout } = useAuth();

  return (
    <aside className="w-56 bg-surface border-r border-border flex flex-col shrink-0">
      <div className="p-4 border-b border-border">
        <Link to="/" className="flex items-center gap-2 text-accent font-semibold">
          <span className="text-xl">◈</span>
          ReconGraph
        </Link>
      </div>
      <nav className="p-2 flex-1">
        <Link
          to="/"
          className="flex items-center gap-2 px-3 py-2 rounded text-gray-400 hover:bg-border hover:text-white transition"
        >
          <Home size={18} />
          Projects
        </Link>
        {projectId && (
          <>
            <Link
              to={`/project/${projectId}`}
              className="flex items-center gap-2 px-3 py-2 rounded text-gray-400 hover:bg-border hover:text-white transition mt-1"
            >
              <LayoutDashboard size={18} />
              Dashboard
            </Link>
            <Link
              to={`/project/${projectId}/graph`}
              className="flex items-center gap-2 px-3 py-2 rounded text-gray-400 hover:bg-border hover:text-white transition"
            >
              <GitBranch size={18} />
              Graph
            </Link>
            <Link
              to={`/project/${projectId}/entry`}
              className="flex items-center gap-2 px-3 py-2 rounded text-gray-400 hover:bg-border hover:text-white transition"
            >
              <PenLine size={18} />
              Data Entry
            </Link>
            <Link
              to={`/project/${projectId}/import`}
              className="flex items-center gap-2 px-3 py-2 rounded text-gray-400 hover:bg-border hover:text-white transition"
            >
              <FileInput size={18} />
              Import / Export
            </Link>
          </>
        )}
      </nav>
      {isProtected && (
        <div className="p-2 border-t border-border">
          <button
            onClick={logout}
            className="flex items-center gap-2 px-3 py-2 w-full rounded text-gray-400 hover:bg-border hover:text-white transition text-sm"
          >
            <LogOut size={18} />
            Lock
          </button>
        </div>
      )}
    </aside>
  );
}
