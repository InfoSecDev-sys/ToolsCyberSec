import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import api, { type DashboardStats, type Project } from '../api/client';
import { GitBranch, Server, Globe, Activity, Shield, Target, TrendingUp } from 'lucide-react';

export default function Dashboard() {
  const { projectId } = useParams<{ projectId: string }>();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [project, setProject] = useState<Project | null>(null);

  useEffect(() => {
    if (!projectId) return;
    const id = parseInt(projectId, 10);
    api.get<Project>(`/projects/${id}`).then((r) => setProject(r.data)).catch(() => {});
    api.get<DashboardStats>(`/projects/${id}/dashboard`).then((r) => setStats(r.data)).catch(() => {});
  }, [projectId]);

  if (!project) return <div className="p-6 text-muted">Loading...</div>;

  const cards = stats
    ? [
        { label: 'Domains', value: stats.total_domains, icon: Globe, color: 'text-accent' },
        { label: 'Subdomains', value: stats.total_subdomains, icon: Server, color: 'text-white' },
        { label: 'Alive', value: stats.alive_subdomains, icon: Activity, color: 'text-accent' },
        { label: 'Down', value: stats.dead_subdomains, icon: Activity, color: 'text-danger' },
        { label: 'IPs', value: stats.total_ips, icon: Target, color: 'text-white' },
        { label: 'Ports', value: stats.total_ports, icon: Activity, color: 'text-muted' },
        { label: 'Services', value: stats.total_services, icon: Server, color: 'text-white' },
        { label: 'Vulnerabilities', value: stats.total_vulnerabilities, icon: Shield, color: 'text-vuln' },
        { label: 'Exploited', value: stats.exploited_services, icon: Shield, color: 'text-exploit' },
      ]
    : [];

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-semibold text-white">{project.name}</h1>
        <div className="flex gap-2">
          <Link
            to={`/project/${projectId}/graph`}
            className="flex items-center gap-2 px-4 py-2 bg-surface border border-border rounded hover:border-accent/50"
          >
            <GitBranch size={18} />
            Graph
          </Link>
          <Link
            to={`/project/${projectId}/entry`}
            className="px-4 py-2 bg-accent text-void rounded hover:opacity-90"
          >
            Data Entry
          </Link>
        </div>
      </div>

      {!stats ? (
        <p className="text-muted">Loading stats...</p>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
            {cards.map((c) => (
              <div
                key={c.label}
                className="p-4 bg-surface border border-border rounded-lg flex items-center gap-3"
              >
                <c.icon size={24} className={c.color} />
                <div>
                  <div className="text-2xl font-semibold text-white">{c.value}</div>
                  <div className="text-sm text-muted">{c.label}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="p-5 bg-surface border border-border rounded-lg">
              <div className="flex items-center gap-2 text-accent mb-2">
                <TrendingUp size={20} />
                <span className="font-medium">Recon Progress</span>
              </div>
              <div className="h-3 bg-void rounded-full overflow-hidden">
                <div
                  className="h-full bg-accent rounded-full transition-all"
                  style={{ width: `${stats.recon_progress_pct}%` }}
                />
              </div>
              <div className="text-sm text-muted mt-1">{stats.recon_progress_pct}%</div>
            </div>
            <div className="p-5 bg-surface border border-border rounded-lg">
              <div className="flex items-center gap-2 text-white mb-2">
                <Activity size={20} />
                <span className="font-medium">Enumeration Progress</span>
              </div>
              <div className="h-3 bg-void rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full transition-all"
                  style={{ width: `${stats.enumeration_progress_pct}%` }}
                />
              </div>
              <div className="text-sm text-muted mt-1">{stats.enumeration_progress_pct}%</div>
            </div>
            <div className="p-5 bg-surface border border-border rounded-lg">
              <div className="flex items-center gap-2 text-exploit mb-2">
                <Shield size={20} />
                <span className="font-medium">Exploitation Progress</span>
              </div>
              <div className="h-3 bg-void rounded-full overflow-hidden">
                <div
                  className="h-full bg-exploit rounded-full transition-all"
                  style={{ width: `${stats.exploitation_progress_pct}%` }}
                />
              </div>
              <div className="text-sm text-muted mt-1">{stats.exploitation_progress_pct}%</div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
