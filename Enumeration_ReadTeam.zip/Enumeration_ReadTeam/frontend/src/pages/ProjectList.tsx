import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { type Project } from '../api/client';
import { Plus, FolderOpen } from 'lucide-react';

export default function ProjectList() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');

  useEffect(() => {
    api.get<Project[]>('/projects').then((r) => {
      setProjects(r.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const createProject = () => {
    if (!newName.trim()) return;
    api.post<Project>('/projects', { name: newName.trim(), description: newDesc.trim() })
      .then((r) => {
        setProjects((p) => [...p, r.data]);
        setNewName('');
        setNewDesc('');
        setShowNew(false);
      });
  };

  return (
    <div className="p-6 max-w-4xl">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-semibold text-white">Projects</h1>
        <button
          onClick={() => setShowNew(!showNew)}
          className="flex items-center gap-2 px-4 py-2 bg-accent text-void rounded hover:opacity-90 transition"
        >
          <Plus size={18} />
          New Project
        </button>
      </div>

      {showNew && (
        <div className="mb-6 p-4 bg-surface border border-border rounded-lg">
          <input
            placeholder="Project name"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            className="w-full px-3 py-2 bg-void border border-border rounded text-white placeholder-gray-500 mb-2"
          />
          <input
            placeholder="Description (optional)"
            value={newDesc}
            onChange={(e) => setNewDesc(e.target.value)}
            className="w-full px-3 py-2 bg-void border border-border rounded text-white placeholder-gray-500 mb-3"
          />
          <div className="flex gap-2">
            <button onClick={createProject} className="px-4 py-2 bg-accent text-void rounded hover:opacity-90">
              Create
            </button>
            <button onClick={() => setShowNew(false)} className="px-4 py-2 bg-border text-gray-300 rounded hover:bg-muted">
              Cancel
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <p className="text-muted">Loading...</p>
      ) : projects.length === 0 ? (
        <p className="text-muted">No projects yet. Create one to start.</p>
      ) : (
        <div className="grid gap-3">
          {projects.map((p) => (
            <Link
              key={p.id}
              to={`/project/${p.id}`}
              className="flex items-center gap-3 p-4 bg-surface border border-border rounded-lg hover:border-accent/50 transition"
            >
              <FolderOpen className="text-accent shrink-0" size={24} />
              <div className="min-w-0">
                <div className="font-medium text-white">{p.name}</div>
                {p.description && <div className="text-sm text-muted truncate">{p.description}</div>}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
