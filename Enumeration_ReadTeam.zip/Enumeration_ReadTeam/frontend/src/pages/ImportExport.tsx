import { useParams } from 'react-router-dom';
import { useState } from 'react';
import api from '../api/client';

export default function ImportExport() {
  const { projectId } = useParams<{ projectId: string }>();
  const [domainId, setDomainId] = useState('');
  const [subdomainId, setSubdomainId] = useState('');
  const [importType, setImportType] = useState<'subdomains' | 'nmap' | 'users'>('subdomains');
  const [subdomainStatus, setSubdomainStatus] = useState('unknown');
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importResult, setImportResult] = useState<string | null>(null);
  const [domains, setDomains] = useState<{ id: number; name: string }[]>([]);
  const [subdomains, setSubdomains] = useState<{ id: number; name: string }[]>([]);
  const [seedResult, setSeedResult] = useState<string | null>(null);

  const pid = projectId ? parseInt(projectId, 10) : 0;

  const seedExample = () => {
    if (!pid) return;
    setSeedResult(null);
    api.post(`/projects/${pid}/seed`)
      .then((r) => {
        setSeedResult(r.data.message + (r.data.domain_id ? ` (domain_id: ${r.data.domain_id})` : ''));
        loadDomains();
      })
      .catch((e) => setSeedResult(e.response?.data?.detail || 'Seed failed'));
  };

  const loadDomains = () => {
    if (!pid) return;
    api.get(`/projects/${pid}/domains`).then((r) => setDomains(r.data));
  };

  const loadSubdomains = () => {
    if (!pid || !domainId) return;
    api.get(`/projects/${pid}/domains/${domainId}/subdomains`).then((r) => setSubdomains(r.data));
  };

  const runImport = async () => {
    if (!pid || !importFile) return;
    setImportResult(null);
    const form = new FormData();
    form.append('file', importFile);
    try {
      if (importType === 'subdomains') {
        if (!domainId) { setImportResult('Select a domain'); return; }
        const r = await api.post(`/projects/${pid}/import/subdomains?domain_id=${domainId}&default_status=${subdomainStatus}`, form, { headers: { 'Content-Type': 'multipart/form-data' } });
        setImportResult(`Imported ${r.data.imported} subdomains (${r.data.total_lines} lines).`);
      } else if (importType === 'users') {
        if (!domainId || !subdomainId) { setImportResult('Select domain and subdomain'); return; }
        const r = await api.post(`/projects/${pid}/import/users?domain_id=${domainId}&subdomain_id=${subdomainId}`, form, { headers: { 'Content-Type': 'multipart/form-data' } });
        setImportResult(`Imported ${r.data.imported} users (${r.data.total_lines} lines).`);
      } else {
        if (!domainId || !subdomainId) { setImportResult('Select domain and subdomain'); return; }
        const r = await api.post(`/projects/${pid}/import/nmap?domain_id=${domainId}&subdomain_id=${subdomainId}`, form, { headers: { 'Content-Type': 'multipart/form-data' } });
        setImportResult(`Imported ${r.data.imported_ips} IPs, ${r.data.imported_ports} ports.`);
      }
    } catch (e: unknown) {
      setImportResult((e as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Import failed');
    }
  };

  const exportJson = () => {
    if (!pid) return;
    window.open(`/api/projects/${pid}/export/json`, '_blank');
  };
  const exportCsv = () => {
    if (!pid) return;
    window.open(`/api/projects/${pid}/export/csv`, '_blank');
  };
  const exportHtml = () => {
    if (!pid) return;
    window.open(`/api/projects/${pid}/export/html`, '_blank');
  };

  return (
    <div className="p-6 max-w-2xl">
      <h1 className="text-2xl font-semibold text-white mb-6">Import / Export</h1>

      <section className="mb-8">
        <h2 className="text-lg text-accent mb-3">Seed example</h2>
        <p className="text-sm text-muted mb-2">Create one example domain (example.com) with 5 subdomains: www, api, mail, ftp, admin.</p>
        <button onClick={seedExample} className="px-4 py-2 bg-surface border border-accent text-accent rounded hover:bg-accent hover:text-void transition">
          Seed example domain + subdomains
        </button>
        {seedResult && <p className="text-sm text-accent mt-2">{seedResult}</p>}
      </section>

      <section className="mb-8">
        <h2 className="text-lg text-accent mb-3">Export</h2>
        <div className="flex gap-2">
          <button onClick={exportJson} className="px-4 py-2 bg-surface border border-border rounded hover:border-accent/50">
            Export JSON
          </button>
          <button onClick={exportCsv} className="px-4 py-2 bg-surface border border-border rounded hover:border-accent/50">
            Export CSV
          </button>
          <button onClick={exportHtml} className="px-4 py-2 bg-surface border border-border rounded hover:border-accent/50">
            Export HTML Report
          </button>
        </div>
      </section>

      <section>
        <h2 className="text-lg text-accent mb-3">Import</h2>
        <div className="space-y-3 mb-4">
          <div className="flex gap-4 flex-wrap">
            <label>
              <input type="radio" checked={importType === 'subdomains'} onChange={() => setImportType('subdomains')} className="mr-2" />
              Subdomains (txt)
            </label>
            <label>
              <input type="radio" checked={importType === 'nmap'} onChange={() => setImportType('nmap')} className="mr-2" />
              Nmap XML
            </label>
            <label>
              <input type="radio" checked={importType === 'users'} onChange={() => setImportType('users')} className="mr-2" />
              Users (username or user:pass or user,email,pass)
            </label>
          </div>
          <button onClick={loadDomains} className="text-sm text-muted hover:text-white">Load domains</button>
          <select value={domainId} onChange={(e) => { setDomainId(e.target.value); setSubdomains([]); }} onFocus={loadDomains} className="bg-surface border border-border rounded px-3 py-2 text-white w-full">
            <option value="">Select domain</option>
            {domains.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
          {(importType === 'nmap' || importType === 'users') && (
            <>
              <button onClick={loadSubdomains} className="text-sm text-muted hover:text-white">Load subdomains</button>
              <select value={subdomainId} onChange={(e) => setSubdomainId(e.target.value)} onFocus={loadSubdomains} className="bg-surface border border-border rounded px-3 py-2 text-white w-full" disabled={!domainId}>
                <option value="">Select subdomain</option>
                {subdomains.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </>
          )}
          {importType === 'subdomains' && (
            <select value={subdomainStatus} onChange={(e) => setSubdomainStatus(e.target.value)} className="bg-surface border border-border rounded px-3 py-2 text-white">
              <option value="unknown">Default status: Unknown</option>
              <option value="up">Default status: Up</option>
              <option value="down">Default status: Down</option>
              <option value="exploited">Default status: Exploited</option>
            </select>
          )}
          <input type="file" accept={importType === 'nmap' ? '.xml' : '.txt,.csv'} onChange={(e) => setImportFile(e.target.files?.[0] ?? null)} className="block w-full text-sm text-muted file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:bg-accent file:text-void" title={importType === 'users' ? 'One line per user: username, or username:password, or username,email,password' : undefined} />
          <button onClick={runImport} disabled={!importFile} className="px-4 py-2 bg-accent text-void rounded hover:opacity-90 disabled:opacity-50">
            Import
          </button>
          {importResult && <p className="text-sm text-accent">{importResult}</p>}
        </div>
      </section>
    </div>
  );
}
