import { useParams } from 'react-router-dom';
import { useCallback, useEffect, useState, useMemo } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  type Node,
  type Edge,
  type NodeTypes,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import api, { type GraphResponse } from '../api/client';
import GraphNode from '../components/GraphNode';

const nodeColors: Record<string, string> = {
  project: '#22c55e',
  domain: '#3b82f6',
  subdomain: '#8b5cf6',
  ip: '#f59e0b',
  port: '#06b6d4',
  service: '#ec4899',
  user: '#84cc16',
  cve: '#ef4444',
};

const statusColors: Record<string, string> = {
  up: '#22c55e',
  down: '#ef4444',
  unknown: '#6b7280',
  exploited: '#a855f7',
  vulnerable: '#f97316',
  exploitable: '#eab308',
  active: '#6b7280',
  inactive: '#4b5563',
};

const nodeTypes: NodeTypes = { recon: GraphNode };

function buildNodesAndEdges(data: GraphResponse): { nodes: Node[]; edges: Edge[] } {
  const nodes: Node[] = data.nodes.map((n) => {
    const color = n.status ? statusColors[n.status] ?? nodeColors[n.type] : nodeColors[n.type] ?? '#6b7280';
    return {
      id: n.id,
      type: 'recon',
      position: { x: 0, y: 0 },
      data: {
        label: n.label,
        type: n.type,
        status: n.status,
        copyText: n.data?.copyText ?? n.label,
        linkUrl: n.data?.linkUrl,
        os_type: n.data?.os_type,
      },
      style: {
        background: color,
        color: '#0a0a0f',
        border: '1px solid rgba(255,255,255,0.2)',
        borderRadius: 6,
        padding: 0,
        fontSize: 12,
      },
    };
  });
  const edges: Edge[] = data.edges.map((e) => ({
    id: e.id,
    source: e.source,
    target: e.target,
    style: { stroke: '#4b5563' },
  }));
  return { nodes, edges };
}

// Simple dagre-like layout: level by type and index
function layout(nodes: Node[], edges: Edge[]): Node[] {
  const levels: Record<string, number> = { project: 0, domain: 1, subdomain: 2, ip: 3, port: 4, service: 5, user: 5, cve: 5 };
  const byLevel: Record<number, string[]> = {};
  const visited = new Set<string>();
  const queue = nodes.length ? [nodes[0].id] : [];
  while (queue.length) {
    const id = queue.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);
    const node = nodes.find((n) => n.id === id);
    const typ = (node?.data?.type as string) ?? 'project';
    const lvl = levels[typ] ?? 0;
    if (!byLevel[lvl]) byLevel[lvl] = [];
    byLevel[lvl].push(id);
    edges.filter((e) => e.source === id).forEach((e) => queue.push(e.target));
  }
  nodes.forEach((n) => {
    const typ = (n.data?.type as string) ?? 'project';
    const lvl = levels[typ] ?? 0;
    if (!byLevel[lvl]) byLevel[lvl] = [];
    if (!byLevel[lvl].includes(n.id)) byLevel[lvl].push(n.id);
  });
  const W = 220;
  const H = 50;
  const out: Node[] = [];
  Object.entries(byLevel).forEach(([lvl, ids]) => {
    const level = parseInt(lvl, 10);
    ids.forEach((id, i) => {
      const node = nodes.find((n) => n.id === id);
      if (node)
        out.push({
          ...node,
          position: { x: level * W, y: i * H },
        });
    });
  });
  return out;
}

export default function GraphView() {
  const { projectId } = useParams<{ projectId: string }>();
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [loading, setLoading] = useState(true);
  const [aliveOnly, setAliveOnly] = useState(false);
  const [vulnerableOnly, setVulnerableOnly] = useState(false);

  const loadGraph = useCallback(() => {
    if (!projectId) return;
    const params = new URLSearchParams();
    if (aliveOnly) params.set('alive_only', 'true');
    if (vulnerableOnly) params.set('vulnerable_only', 'true');
    api
      .get<GraphResponse>(`/projects/${projectId}/graph?${params}`)
      .then((r) => {
        const { nodes: n, edges: e } = buildNodesAndEdges(r.data);
        const laid = layout(n, e);
        setNodes(laid);
        setEdges(e);
      })
      .finally(() => setLoading(false));
  }, [projectId, aliveOnly, vulnerableOnly]);

  useEffect(() => {
    setLoading(true);
    loadGraph();
  }, [loadGraph]);

  if (!projectId) return null;

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center gap-4 p-3 bg-surface border-b border-border shrink-0">
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={aliveOnly}
            onChange={(e) => setAliveOnly(e.target.checked)}
            className="rounded border-border bg-void text-accent"
          />
          Alive only
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={vulnerableOnly}
            onChange={(e) => setVulnerableOnly(e.target.checked)}
            className="rounded border-border bg-void text-accent"
          />
          Vulnerable/Exploitable only
        </label>
        <button
          onClick={() => { setLoading(true); loadGraph(); }}
          className="px-3 py-1 bg-border rounded text-sm hover:bg-muted"
        >
          Refresh
        </button>
      </div>
      <div className="flex-1">
        {loading ? (
          <div className="flex items-center justify-center h-full text-muted">Loading graph...</div>
        ) : (
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            nodeTypes={nodeTypes}
            fitView
            className="bg-void"
          >
            <Background color="#1e1e2e" gap={16} />
            <Controls className="!bg-surface !border-border !text-white" />
            <MiniMap
              nodeColor={(n) => (n.data?.status ? statusColors[n.data.status as string] : nodeColors[n.data?.type as string]) ?? '#374151'}
              className="!bg-surface !border-border"
            />
          </ReactFlow>
        )}
      </div>
    </div>
  );
}
