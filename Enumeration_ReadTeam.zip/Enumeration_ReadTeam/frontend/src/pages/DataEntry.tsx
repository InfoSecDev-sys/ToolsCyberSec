import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import api, {
  type Project,
  type Domain,
  type Subdomain,
  type IPAddress,
  type Port,
  type Service,
  type User,
  type CVE,
} from '../api/client';
import { PORT_PROTOCOLS } from '../constants/protocols';

type Tab = 'domain' | 'subdomain' | 'ip' | 'port' | 'service' | 'user' | 'cve';

export default function DataEntry() {
  const { projectId } = useParams<{ projectId: string }>();
  const [project, setProject] = useState<Project | null>(null);
  const [domains, setDomains] = useState<Domain[]>([]);
  const [subdomains, setSubdomains] = useState<Subdomain[]>([]);
  const [ips, setIps] = useState<IPAddress[]>([]);
  const [ports, setPorts] = useState<Port[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [cves, setCves] = useState<CVE[]>([]);

  const [selectedDomainId, setSelectedDomainId] = useState<number | null>(null);
  const [selectedSubdomainId, setSelectedSubdomainId] = useState<number | null>(null);
  const [selectedIpId, setSelectedIpId] = useState<number | null>(null);
  const [selectedPortId, setSelectedPortId] = useState<number | null>(null);

  const [tab, setTab] = useState<Tab>('domain');
  const [formName, setFormName] = useState('');
  const [formExtra, setFormExtra] = useState<Record<string, string>>({});
  const [message, setMessage] = useState('');
  const [bulkPorts, setBulkPorts] = useState('');
  const [editSubdomainStatus, setEditSubdomainStatus] = useState('');
  const [savingStatus, setSavingStatus] = useState(false);

  const pid = projectId ? parseInt(projectId, 10) : 0;

  useEffect(() => {
    if (!pid) return;
    api.get<Project>(`/projects/${pid}`).then((r) => setProject(r.data));
    api.get<Domain[]>(`/projects/${pid}/domains`).then((r) => setDomains(r.data));
  }, [pid]);

  useEffect(() => {
    if (!pid || !selectedDomainId) {
      setSubdomains([]);
      setSelectedSubdomainId(null);
      return;
    }
    api.get<Subdomain[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains`).then((r) => setSubdomains(r.data));
  }, [pid, selectedDomainId]);

  useEffect(() => {
    if (!pid || !selectedDomainId || !selectedSubdomainId) {
      setIps([]);
      setSelectedIpId(null);
      return;
    }
    api.get<IPAddress[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips`).then((r) => setIps(r.data));
  }, [pid, selectedDomainId, selectedSubdomainId]);

  useEffect(() => {
    if (!pid || !selectedDomainId || !selectedSubdomainId || !selectedIpId) {
      setPorts([]);
      setSelectedPortId(null);
      return;
    }
    api.get<Port[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips/${selectedIpId}/ports`).then((r) => setPorts(r.data));
  }, [pid, selectedDomainId, selectedSubdomainId, selectedIpId]);

  useEffect(() => {
    if (!pid || !selectedDomainId || !selectedSubdomainId || !selectedPortId) {
      setServices([]);
      return;
    }
    api.get<Service[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips/${selectedIpId}/ports/${selectedPortId}/services`).then((r) => setServices(r.data));
  }, [pid, selectedDomainId, selectedSubdomainId, selectedIpId, selectedPortId]);

  useEffect(() => {
    if (!pid || !selectedDomainId || !selectedSubdomainId) {
      setUsers([]);
      setCves([]);
      return;
    }
    api.get<User[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/users`).then((r) => setUsers(r.data));
    api.get<CVE[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/cves`).then((r) => setCves(r.data));
  }, [pid, selectedDomainId, selectedSubdomainId]);

  useEffect(() => {
    const sub = subdomains.find((s) => s.id === selectedSubdomainId);
    setEditSubdomainStatus(sub?.status ?? '');
  }, [selectedSubdomainId, subdomains]);

  const submit = () => {
    setMessage('');
    if (!pid) return;
    if (tab === 'domain') {
      if (!formName.trim()) return;
      api.post(`/projects/${pid}/domains`, { project_id: pid, name: formName.trim(), notes: formExtra.notes || '', in_scope: true })
        .then(() => { setFormName(''); setMessage('Domain added.'); api.get<Domain[]>(`/projects/${pid}/domains`).then((r) => setDomains(r.data)); })
        .catch((e) => setMessage(e.response?.data?.detail || 'Error'));
      return;
    }
    if (tab === 'subdomain') {
      if (!selectedDomainId || !formName.trim()) return;
      api.post(`/projects/${pid}/domains/${selectedDomainId}/subdomains`, { domain_id: selectedDomainId, name: formName.trim(), status: formExtra.status || 'unknown' })
        .then(() => { setFormName(''); setMessage('Subdomain added.'); api.get<Subdomain[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains`).then((r) => setSubdomains(r.data)); })
        .catch((e) => setMessage(e.response?.data?.detail || 'Error'));
      return;
    }
    if (tab === 'ip') {
      if (!selectedDomainId || !selectedSubdomainId || !formName.trim()) return;
      api.post(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips`, { subdomain_id: selectedSubdomainId, address: formName.trim(), os_type: formExtra.os_type || 'unknown' })
        .then(() => { setFormName(''); setMessage('IP added.'); api.get<IPAddress[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips`).then((r) => setIps(r.data)); })
        .catch((e) => setMessage(e.response?.data?.detail || 'Error'));
      return;
    }
    if (tab === 'port') {
      if (!selectedDomainId || !selectedSubdomainId || !selectedIpId || !formName.trim()) return;
      const num = parseInt(formName.trim(), 10);
      if (isNaN(num)) { setMessage('Port must be a number'); return; }
      api.post(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips/${selectedIpId}/ports`, { ip_id: selectedIpId, number: num, protocol: formExtra.protocol || 'tcp' })
        .then(() => { setFormName(''); setMessage('Port added.'); api.get<Port[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips/${selectedIpId}/ports`).then((r) => setPorts(r.data)); })
        .catch((e) => setMessage(e.response?.data?.detail || 'Error'));
      return;
    }
    if (tab === 'service') {
      if (!selectedDomainId || !selectedSubdomainId || !selectedIpId || !selectedPortId || !formName.trim()) return;
      api.post(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips/${selectedIpId}/ports/${selectedPortId}/services`, { port_id: selectedPortId, name: formName.trim(), version: formExtra.version || '', status: formExtra.status || 'active' })
        .then(() => { setFormName(''); setMessage('Service added.'); api.get<Service[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips/${selectedIpId}/ports/${selectedPortId}/services`).then((r) => setServices(r.data)); })
        .catch((e) => setMessage(e.response?.data?.detail || 'Error'));
      return;
    }
    if (tab === 'user') {
      if (!selectedDomainId || !selectedSubdomainId || !formName.trim()) return;
      const password = formExtra.password || '';
      api.post(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/users`, { subdomain_id: selectedSubdomainId, username: formName.trim(), email: formExtra.email || '' })
        .then((r) => {
          if (password && r.data?.id) {
            return api.post(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/users/${r.data.id}/credentials`, { user_id: r.data.id, password }).then(() => r);
          }
          return r;
        })
        .then(() => { setFormName(''); setFormExtra((x) => ({ ...x, password: '', email: '' })); setMessage('User added.' + (password ? ' Password saved.' : '')); api.get<User[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/users`).then((res) => setUsers(res.data)); })
        .catch((e) => setMessage(e.response?.data?.detail || 'Error'));
      return;
    }
    if (tab === 'cve') {
      if (!selectedDomainId || !selectedSubdomainId || !formName.trim()) return;
      api.post(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/cves`, { subdomain_id: selectedSubdomainId, cve_id: formName.trim(), severity: formExtra.severity || '' })
        .then(() => { setFormName(''); setMessage('CVE added.'); api.get<CVE[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/cves`).then((r) => setCves(r.data)); })
        .catch((e) => setMessage(e.response?.data?.detail || 'Error'));
    }
  };

  const tabs: { id: Tab; label: string; needDomain: boolean; needSub: boolean; needIp: boolean; needPort: boolean }[] = [
    { id: 'domain', label: 'Domain', needDomain: false, needSub: false, needIp: false, needPort: false },
    { id: 'subdomain', label: 'Subdomain', needDomain: true, needSub: false, needIp: false, needPort: false },
    { id: 'ip', label: 'IP', needDomain: true, needSub: true, needIp: false, needPort: false },
    { id: 'port', label: 'Port', needDomain: true, needSub: true, needIp: true, needPort: false },
    { id: 'service', label: 'Service', needDomain: true, needSub: true, needIp: true, needPort: true },
    { id: 'user', label: 'User', needDomain: true, needSub: true, needIp: false, needPort: false },
    { id: 'cve', label: 'CVE', needDomain: true, needSub: true, needIp: false, needPort: false },
  ];

  const canAdd = (t: (typeof tabs)[0]) => {
    if (t.needDomain && !selectedDomainId) return false;
    if (t.needSub && !selectedSubdomainId) return false;
    if (t.needIp && !selectedIpId) return false;
    if (t.needPort && !selectedPortId) return false;
    return true;
  };

  if (!project) return <div className="p-6 text-muted">Loading...</div>;

  return (
    <div className="p-6 max-w-4xl">
      <h1 className="text-2xl font-semibold text-white mb-6">Data Entry — {project.name}</h1>
      <p className="text-sm text-muted mb-4">Select parent entities first (Domain → Subdomain → IP → Port) then add children.</p>

      <div className="flex flex-wrap gap-2 mb-6">
        <span className="text-muted text-sm">Select:</span>
        <select
          value={selectedDomainId ?? ''}
          onChange={(e) => setSelectedDomainId(e.target.value ? parseInt(e.target.value, 10) : null)}
          className="bg-surface border border-border rounded px-3 py-1.5 text-sm"
        >
          <option value="">Domain...</option>
          {domains.map((d) => (
            <option key={d.id} value={d.id}>{d.name}</option>
          ))}
        </select>
        <select
          value={selectedSubdomainId ?? ''}
          onChange={(e) => setSelectedSubdomainId(e.target.value ? parseInt(e.target.value, 10) : null)}
          disabled={!selectedDomainId}
          className="bg-surface border border-border rounded px-3 py-1.5 text-sm disabled:opacity-50"
        >
          <option value="">Subdomain...</option>
          {subdomains.map((s) => (
            <option key={s.id} value={s.id}>{s.name} ({s.status})</option>
          ))}
        </select>
        <select
          value={selectedIpId ?? ''}
          onChange={(e) => setSelectedIpId(e.target.value ? parseInt(e.target.value, 10) : null)}
          disabled={!selectedSubdomainId}
          className="bg-surface border border-border rounded px-3 py-1.5 text-sm disabled:opacity-50"
        >
          <option value="">IP...</option>
          {ips.map((ip) => (
            <option key={ip.id} value={ip.id}>{ip.address}</option>
          ))}
        </select>
        <select
          value={selectedPortId ?? ''}
          onChange={(e) => setSelectedPortId(e.target.value ? parseInt(e.target.value, 10) : null)}
          disabled={!selectedIpId}
          className="bg-surface border border-border rounded px-3 py-1.5 text-sm disabled:opacity-50"
        >
          <option value="">Port...</option>
          {ports.map((p) => (
            <option key={p.id} value={p.id}>{p.number}/{p.protocol}</option>
          ))}
        </select>
      </div>

      {selectedSubdomainId && (
        <div className="mb-4 p-3 bg-surface border border-border rounded-lg flex flex-wrap items-center gap-2">
          <span className="text-sm text-muted">Edit subdomain status:</span>
          <select
            value={editSubdomainStatus}
            onChange={(e) => setEditSubdomainStatus(e.target.value)}
            className="bg-void border border-border rounded px-3 py-1.5 text-sm text-white"
          >
            <option value="up">Up</option>
            <option value="down">Down</option>
            <option value="unknown">Unknown</option>
            <option value="exploited">Exploited</option>
          </select>
          <button
            onClick={() => {
              if (!selectedDomainId || !selectedSubdomainId) return;
              setSavingStatus(true);
              api.patch(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}`, { status: editSubdomainStatus })
                .then(() => { setMessage('Status updated.'); api.get<Subdomain[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains`).then((r) => setSubdomains(r.data)); })
                .catch((e) => setMessage(e.response?.data?.detail || 'Error'))
                .finally(() => setSavingStatus(false));
            }}
            disabled={savingStatus}
            className="px-3 py-1.5 bg-accent text-void rounded text-sm hover:opacity-90 disabled:opacity-50"
          >
            Save status
          </button>
        </div>
      )}

      <div className="flex gap-2 mb-4 border-b border-border pb-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            disabled={!canAdd(t) && t.id !== 'domain'}
            className={`px-3 py-1.5 rounded text-sm ${tab === t.id ? 'bg-accent text-void' : 'bg-surface border border-border hover:border-accent/50'} disabled:opacity-50`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="p-4 bg-surface border border-border rounded-lg space-y-3">
        {tab === 'domain' && <input placeholder="Domain name" value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />}
        {tab === 'subdomain' && (
          <>
            <input placeholder="Subdomain (e.g. www.example.com)" value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />
            <select value={formExtra.status ?? 'unknown'} onChange={(e) => setFormExtra((x) => ({ ...x, status: e.target.value }))} className="bg-void border border-border rounded px-3 py-2 text-white">
              <option value="up">Up</option>
              <option value="down">Down</option>
              <option value="unknown">Unknown</option>
              <option value="exploited">Exploited</option>
            </select>
          </>
        )}
        {tab === 'ip' && (
          <>
            <input placeholder="IP address" value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />
            <select value={formExtra.os_type ?? 'unknown'} onChange={(e) => setFormExtra((x) => ({ ...x, os_type: e.target.value }))} className="bg-void border border-border rounded px-3 py-2 text-white">
              <option value="unknown">Unknown</option>
              <option value="windows">Windows</option>
              <option value="windows_server">Windows Server</option>
              <option value="linux">Linux</option>
              <option value="ubuntu">Ubuntu</option>
              <option value="kali">Kali</option>
              <option value="macos">macOS</option>
              <option value="network_device">Network Device</option>
            </select>
          </>
        )}
        {tab === 'port' && (
          <>
            <div className="text-sm text-muted mb-1">Single port</div>
            <div className="flex gap-2 flex-wrap">
              <input placeholder="Port (e.g. 22)" value={formName} onChange={(e) => setFormName(e.target.value)} className="flex-1 min-w-[80px] px-3 py-2 bg-void border border-border rounded text-white" />
              <select value={formExtra.protocol ?? 'tcp'} onChange={(e) => setFormExtra((x) => ({ ...x, protocol: e.target.value }))} className="bg-void border border-border rounded px-3 py-2 text-white">
                <option value="tcp">TCP</option>
                <option value="udp">UDP</option>
              </select>
            </div>
            <div className="text-sm text-muted mt-2 mb-1">Or quick-add by protocol</div>
            <select
              value=""
              onChange={(e) => {
                const v = e.target.value;
                if (!v) return;
                const [portStr, protocol] = v.split('/');
                const num = parseInt(portStr, 10);
                if (!selectedIpId || isNaN(num)) return;
                api.post(`/projects/${pid}/domains/${selectedDomainId!}/subdomains/${selectedSubdomainId!}/ips/${selectedIpId}/ports`, { ip_id: selectedIpId, number: num, protocol: protocol || 'tcp' })
                  .then(() => { setMessage(`Port ${num}/${protocol} added.`); api.get<Port[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips/${selectedIpId}/ports`).then((r) => setPorts(r.data)); })
                  .catch((err) => setMessage(err.response?.data?.detail || 'Error'));
                e.target.value = '';
              }}
              className="w-full bg-void border border-border rounded px-3 py-2 text-white"
            >
              <option value="">-- Select protocol (SSH, FTP, HTTP, SMB...) --</option>
              {PORT_PROTOCOLS.map((p) => (
                <option key={p.port} value={`${p.port}/${p.protocol}`}>{p.port} - {p.name} ({p.protocol})</option>
              ))}
            </select>
            <div className="text-sm text-muted mt-2 mb-1">Or bulk: comma/spaces (e.g. 22,21,80,443)</div>
            <div className="flex gap-2">
              <input placeholder="22, 21, 80, 443" value={bulkPorts} onChange={(e) => setBulkPorts(e.target.value)} className="flex-1 px-3 py-2 bg-void border border-border rounded text-white" />
              <button
                onClick={() => {
                  if (!bulkPorts.trim() || !selectedIpId) return;
                  api.post(`/projects/${pid}/domains/${selectedDomainId!}/subdomains/${selectedSubdomainId!}/ips/${selectedIpId}/ports/bulk`, { ports: bulkPorts.trim(), protocol: formExtra.protocol || 'tcp' })
                    .then((r) => { setBulkPorts(''); setMessage(`Added ${r.data.created} port(s).`); api.get<Port[]>(`/projects/${pid}/domains/${selectedDomainId}/subdomains/${selectedSubdomainId}/ips/${selectedIpId}/ports`).then((res) => setPorts(res.data)); })
                    .catch((err) => setMessage(err.response?.data?.detail || 'Error'));
                }}
                disabled={!bulkPorts.trim()}
                className="px-4 py-2 bg-border text-white rounded hover:bg-muted disabled:opacity-50"
              >
                Add bulk
              </button>
            </div>
          </>
        )}
        {tab === 'service' && (
          <>
            <input placeholder="Service name (e.g. ssh, http, smb)" value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />
            <select
              onChange={(e) => { const v = e.target.value; if (v) setFormName(v); e.target.value = ''; }}
              className="w-full bg-void border border-border rounded px-3 py-2 text-white"
            >
              <option value="">-- Quick: SSH, FTP, HTTP, SMB... --</option>
              {['ssh','ftp','http','https','smb','smtp','rdp','mssql','mysql','postgres','redis','vnc','telnet','imap','pop3'].map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <input placeholder="Version (optional)" value={formExtra.version ?? ''} onChange={(e) => setFormExtra((x) => ({ ...x, version: e.target.value }))} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />
            <select value={formExtra.status ?? 'active'} onChange={(e) => setFormExtra((x) => ({ ...x, status: e.target.value }))} className="bg-void border border-border rounded px-3 py-2 text-white">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="vulnerable">Vulnerable</option>
              <option value="exploitable">Exploitable</option>
              <option value="exploited">Exploited</option>
            </select>
          </>
        )}
        {tab === 'user' && (
          <>
            <input placeholder="Username" value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />
            <input placeholder="Email (optional)" value={formExtra.email ?? ''} onChange={(e) => setFormExtra((x) => ({ ...x, email: e.target.value }))} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />
            <input type="password" placeholder="Password (optional)" value={formExtra.password ?? ''} onChange={(e) => setFormExtra((x) => ({ ...x, password: e.target.value }))} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />
          </>
        )}
        {tab === 'cve' && (
          <>
            <input placeholder="CVE-ID (e.g. CVE-2024-1234)" value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />
            <input placeholder="Severity (optional)" value={formExtra.severity ?? ''} onChange={(e) => setFormExtra((x) => ({ ...x, severity: e.target.value }))} className="w-full px-3 py-2 bg-void border border-border rounded text-white" />
          </>
        )}
        <button onClick={submit} disabled={(tab === 'domain' || tab === 'subdomain' || tab === 'ip' || tab === 'port' || tab === 'service' || tab === 'user' || tab === 'cve') && !formName.trim()} className="px-4 py-2 bg-accent text-void rounded hover:opacity-90 disabled:opacity-50">
          Add {tabs.find((t) => t.id === tab)?.label}
        </button>
        {message && <p className="text-sm text-accent">{message}</p>}
      </div>
    </div>
  );
}
