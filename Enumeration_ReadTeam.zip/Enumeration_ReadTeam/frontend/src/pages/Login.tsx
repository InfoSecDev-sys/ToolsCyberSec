import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Lock, AlertCircle } from 'lucide-react';

export default function Login() {
  const { login } = useAuth();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(password);
    } catch (err: unknown) {
      setError((err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Invalid password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-bg">
        <div className="login-grid" />
        <div className="login-scan" />
        <div className="login-glow" />
      </div>
      <div className="login-card">
        <div className="flex items-center justify-center gap-2 text-accent mb-6">
          <span className="text-3xl">◈</span>
          <h1 className="text-2xl font-semibold tracking-wider">ReconGraph</h1>
        </div>
        <p className="text-sm text-muted text-center mb-6">Red Team Recon & Enumeration Platform</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" size={18} />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="w-full pl-10 pr-4 py-3 bg-void border border-border rounded text-white placeholder-gray-500 focus:border-accent focus:outline-none"
              autoFocus
            />
          </div>
          {error && (
            <div className="flex items-center gap-2 text-danger text-sm">
              <AlertCircle size={16} />
              {error}
            </div>
          )}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-accent text-void font-medium rounded hover:opacity-90 disabled:opacity-50 transition"
          >
            {loading ? '...' : 'Unlock'}
          </button>
        </form>
        <p className="text-xs text-muted text-center mt-6">Local only · No telemetry</p>
      </div>
    </div>
  );
}
