# ReconGraph — Cybersecurity Recon & Enumeration Management Platform

A web-based application for red teams and penetration testers to organize, visualize, and track reconnaissance and enumeration data during cybersecurity assessments.

## Features

- **Multiple projects** — Separate engagements with isolated data
- **Hierarchical data model** — Project → Domain → Subdomain → IP → Port → Service, plus Users, CVEs, Notes
- **Strict data entry flow** — UI enforces logical order (e.g. cannot add subdomain without domain)
- **Interactive graph** — React Flow–based visualization with filters (alive only, vulnerable/exploitable only)
- **Status tracking** — Subdomain: Up/Down/Unknown; Service: Active/Vulnerable/Exploitable/Exploited
- **Dashboard** — Counts and progress indicators (recon, enumeration, exploitation)
- **Bulk import** — Subdomains (txt, one per line), Nmap XML
- **Export** — JSON, CSV, HTML report
- **Local only** — SQLite database, no cloud, no telemetry
- **Dark UI** — Hacker-style interface with Tailwind

## Tech Stack

- **Backend:** Python 3.10+, FastAPI, SQLAlchemy, SQLite
- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS, React Flow (@xyflow/react)
- **API:** REST; frontend proxies `/api` to backend

## Setup

### Prerequisites

- Python 3.10 or newer
- Node.js 18+ and npm

### Backend

```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
# source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

The API will be at `http://127.0.0.1:8000`. Docs: `http://127.0.0.1:8000/docs`.

Database and uploads are stored under `backend/data/` and `backend/uploads/` (created automatically).

### Frontend

```bash
cd frontend
npm install
npm run dev
```

The app will be at `http://localhost:5173`. It proxies `/api` to `http://127.0.0.1:8000`, so run the backend first.

### One-shot (backend + frontend)

1. Terminal 1: `cd backend && .venv\Scripts\activate && uvicorn app.main:app --reload --port 8000`
2. Terminal 2: `cd frontend && npm run dev`

## Project Structure

```
Enumeration_ReadTeam/
├── backend/
│   ├── app/
│   │   ├── api/          # Routers: projects, domains, subdomains, ips, ports, services, users, cves, notes, icons, dashboard, graph, import_export
│   │   ├── core/         # Config
│   │   ├── db/           # SQLAlchemy engine, session, init_db
│   │   ├── models/       # ORM models
│   │   ├── schemas/      # Pydantic schemas
│   │   └── main.py       # FastAPI app, CORS, route includes
│   ├── data/             # SQLite DB (created at runtime)
│   ├── uploads/          # Uploaded icons (created at runtime)
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── api/          # Axios client, types
│   │   ├── components/   # Layout, Sidebar
│   │   ├── pages/        # ProjectList, Dashboard, GraphView, DataEntry, ImportExport
│   │   ├── App.tsx
│   │   └── main.tsx
│   ├── package.json
│   └── vite.config.ts    # Proxy /api -> backend
└── README.md
```

## Data Entry Rules

- **Domain** — Add first (no parent).
- **Subdomain** — Requires a selected Domain.
- **IP** — Requires a selected Subdomain.
- **Port** — Requires a selected IP.
- **Service** — Requires a selected Port.
- **User / CVE** — Require a selected Subdomain.

Use **Data Entry** in the sidebar and the dropdowns to select parent context, then pick the entity type and submit.

## API Overview

- `GET/POST /projects` — List / create projects
- `GET/POST /projects/{id}/domains` — Domains
- `GET/POST /projects/{id}/domains/{id}/subdomains` — Subdomains
- `GET/POST /projects/.../subdomains/{id}/ips` — IPs
- `GET/POST /projects/.../ips/{id}/ports` — Ports
- `GET/POST /projects/.../ports/{id}/services` — Services
- `GET/POST /projects/.../subdomains/{id}/users` — Users
- `GET/POST /projects/.../subdomains/{id}/cves` — CVEs
- `GET/POST /projects/{id}/notes` — Notes (optional domain_id, subdomain_id)
- `GET /projects/{id}/dashboard` — Dashboard stats
- `GET /projects/{id}/graph?alive_only=&vulnerable_only=` — Graph nodes/edges
- `GET /projects/{id}/export/json|csv|html` — Export
- `POST /projects/{id}/import/subdomains?domain_id=&default_status=` — Import subdomains (file)
- `POST /projects/{id}/import/nmap?domain_id=&subdomain_id=` — Import Nmap XML (file)
- `GET/POST /icons` — List / create icons; `POST /icons/upload` — Upload icon file

## Security

- All data is stored locally (SQLite). No cloud sync or telemetry.
- Optional: add password protection or run behind a reverse proxy with auth for sensitive use.

## License

Use for authorized security assessments only.
