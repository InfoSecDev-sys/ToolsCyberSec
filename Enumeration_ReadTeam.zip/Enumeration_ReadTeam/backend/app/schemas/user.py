from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class UserBase(BaseModel):
    username: str
    email: Optional[str] = ""
    notes: Optional[str] = ""


class UserCreate(UserBase):
    subdomain_id: int


class UserUpdate(BaseModel):
    username: Optional[str] = None
    email: Optional[str] = None
    notes: Optional[str] = None


class UserResponse(UserBase):
    id: int
    subdomain_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
