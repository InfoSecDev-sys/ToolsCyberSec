from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class NoteBase(BaseModel):
    content: str
    tags: Optional[str] = ""


class NoteCreate(NoteBase):
    subdomain_id: Optional[int] = None
    domain_id: Optional[int] = None
    project_id: Optional[int] = None


class NoteUpdate(BaseModel):
    content: Optional[str] = None
    tags: Optional[str] = None
    subdomain_id: Optional[int] = None
    domain_id: Optional[int] = None
    project_id: Optional[int] = None


class NoteResponse(NoteBase):
    id: int
    subdomain_id: Optional[int] = None
    domain_id: Optional[int] = None
    project_id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
