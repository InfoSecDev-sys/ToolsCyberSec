from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from enum import Enum


class SubdomainStatus(str, Enum):
    up = "up"
    down = "down"
    unknown = "unknown"
    exploited = "exploited"


class SubdomainBase(BaseModel):
    name: str
    status: Optional[SubdomainStatus] = SubdomainStatus.unknown


class SubdomainCreate(SubdomainBase):
    domain_id: int


class SubdomainUpdate(BaseModel):
    name: Optional[str] = None
    status: Optional[SubdomainStatus] = None


class SubdomainResponse(SubdomainBase):
    id: int
    domain_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
