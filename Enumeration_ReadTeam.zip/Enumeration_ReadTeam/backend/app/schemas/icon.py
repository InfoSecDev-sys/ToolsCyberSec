from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class IconCreate(BaseModel):
    name: str
    os_type: Optional[str] = ""
    file_path: Optional[str] = ""
    data_url: Optional[str] = ""


class IconResponse(BaseModel):
    id: int
    name: str
    os_type: str
    file_path: Optional[str] = None
    data_url: Optional[str] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
