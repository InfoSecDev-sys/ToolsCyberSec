from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from enum import Enum


class ServiceStatus(str, Enum):
    active = "active"
    inactive = "inactive"
    vulnerable = "vulnerable"
    exploitable = "exploitable"
    exploited = "exploited"


class ServiceBase(BaseModel):
    name: str
    version: Optional[str] = ""
    banner: Optional[str] = ""
    status: Optional[ServiceStatus] = ServiceStatus.active
    notes: Optional[str] = ""


class ServiceCreate(ServiceBase):
    port_id: int


class ServiceUpdate(BaseModel):
    name: Optional[str] = None
    version: Optional[str] = None
    banner: Optional[str] = None
    status: Optional[ServiceStatus] = None
    notes: Optional[str] = None


class ServiceResponse(ServiceBase):
    id: int
    port_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
