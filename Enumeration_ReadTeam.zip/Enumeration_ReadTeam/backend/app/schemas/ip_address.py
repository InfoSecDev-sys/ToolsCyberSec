from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from enum import Enum


class OSType(str, Enum):
    windows = "windows"
    windows_server = "windows_server"
    linux = "linux"
    ubuntu = "ubuntu"
    kali = "kali"
    macos = "macos"
    network_device = "network_device"
    unknown = "unknown"


class IPAddressBase(BaseModel):
    address: str
    os_type: Optional[OSType] = OSType.unknown
    icon_id: Optional[int] = None


class IPAddressCreate(IPAddressBase):
    subdomain_id: int


class IPAddressUpdate(BaseModel):
    address: Optional[str] = None
    os_type: Optional[OSType] = None
    icon_id: Optional[int] = None


class IPAddressResponse(IPAddressBase):
    id: int
    subdomain_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
