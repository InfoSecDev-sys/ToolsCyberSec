from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class DomainBase(BaseModel):
    name: str
    notes: Optional[str] = ""
    in_scope: Optional[bool] = True


class DomainCreate(DomainBase):
    project_id: int


class DomainUpdate(BaseModel):
    name: Optional[str] = None
    notes: Optional[str] = None
    in_scope: Optional[bool] = None


class DomainResponse(DomainBase):
    id: int
    project_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
