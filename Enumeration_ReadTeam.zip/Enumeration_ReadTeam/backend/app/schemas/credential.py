from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class CredentialBase(BaseModel):
    password: Optional[str] = ""
    hash_type: Optional[str] = ""
    notes: Optional[str] = ""


class CredentialCreate(CredentialBase):
    user_id: int


class CredentialUpdate(BaseModel):
    password: Optional[str] = None
    hash_type: Optional[str] = None
    notes: Optional[str] = None


class CredentialResponse(CredentialBase):
    id: int
    user_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
