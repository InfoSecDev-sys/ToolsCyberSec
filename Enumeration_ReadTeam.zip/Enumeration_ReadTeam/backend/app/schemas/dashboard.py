from pydantic import BaseModel


class DashboardStats(BaseModel):
    total_domains: int
    total_subdomains: int
    alive_subdomains: int
    dead_subdomains: int
    total_ips: int
    total_ports: int
    total_services: int
    total_vulnerabilities: int
    exploited_services: int
    recon_progress_pct: float
    enumeration_progress_pct: float
    exploitation_progress_pct: float
