from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class CVEBase(BaseModel):
    cve_id: str
    description: Optional[str] = ""
    severity: Optional[str] = ""
    cvss: Optional[str] = ""
    notes: Optional[str] = ""


class CVECreate(CVEBase):
    subdomain_id: int


class CVEUpdate(BaseModel):
    cve_id: Optional[str] = None
    description: Optional[str] = None
    severity: Optional[str] = None
    cvss: Optional[str] = None
    notes: Optional[str] = None


class CVEResponse(CVEBase):
    id: int
    subdomain_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
