from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class PortBase(BaseModel):
    number: int
    protocol: Optional[str] = "tcp"


class PortCreate(PortBase):
    ip_id: int


class PortUpdate(BaseModel):
    number: Optional[int] = None
    protocol: Optional[str] = None


class BulkPortsCreate(BaseModel):
    ports: str  # e.g. "22,21,80,443"
    protocol: str = "tcp"
    default_service: Optional[str] = None  # optional service name for all


class PortResponse(PortBase):
    id: int
    ip_id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
