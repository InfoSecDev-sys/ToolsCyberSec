from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Enum as SQLEnum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.session import Base
import enum


class OSType(str, enum.Enum):
    WINDOWS = "windows"
    WINDOWS_SERVER = "windows_server"
    LINUX = "linux"
    UBUNTU = "ubuntu"
    KALI = "kali"
    MACOS = "macos"
    NETWORK_DEVICE = "network_device"
    UNKNOWN = "unknown"


class IPAddress(Base):
    __tablename__ = "ip_addresses"

    id = Column(Integer, primary_key=True, index=True)
    subdomain_id = Column(Integer, ForeignKey("subdomains.id", ondelete="CASCADE"), nullable=False, index=True)
    address = Column(String(45), nullable=False, index=True)  # IPv4 or IPv6
    os_type = Column(SQLEnum(OSType), default=OSType.UNKNOWN)
    icon_id = Column(Integer, ForeignKey("icons.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    subdomain = relationship("Subdomain", back_populates="ip_addresses")
    ports = relationship("Port", back_populates="ip_address", cascade="all, delete-orphan")
    icon = relationship("Icon", backref="ip_addresses")
