from sqlalchemy import Column, Integer, String, ForeignKey, Text, Boolean, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.session import Base


class Domain(Base):
    __tablename__ = "domains"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(512), nullable=False, index=True)  # domain name or tenant ID
    notes = Column(Text, default="")
    in_scope = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    project = relationship("Project", back_populates="domains")
    subdomains = relationship("Subdomain", back_populates="domain", cascade="all, delete-orphan")
    note_entries = relationship("Note", back_populates="domain", cascade="all, delete-orphan", foreign_keys="Note.domain_id")
