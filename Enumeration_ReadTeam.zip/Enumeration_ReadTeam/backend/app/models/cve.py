from sqlalchemy import Column, Integer, String, ForeignKey, Text, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.session import Base


class CVE(Base):
    __tablename__ = "cves"

    id = Column(Integer, primary_key=True, index=True)
    subdomain_id = Column(Integer, ForeignKey("subdomains.id", ondelete="CASCADE"), nullable=False, index=True)
    cve_id = Column(String(32), nullable=False, index=True)  # e.g. CVE-2024-1234
    description = Column(Text, default="")
    severity = Column(String(32), default="")  # critical, high, medium, low
    cvss = Column(String(16), default="")
    notes = Column(Text, default="")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    subdomain = relationship("Subdomain", back_populates="cves")
