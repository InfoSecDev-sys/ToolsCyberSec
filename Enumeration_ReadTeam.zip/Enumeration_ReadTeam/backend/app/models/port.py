from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.session import Base


class Port(Base):
    __tablename__ = "ports"

    id = Column(Integer, primary_key=True, index=True)
    ip_id = Column(Integer, ForeignKey("ip_addresses.id", ondelete="CASCADE"), nullable=False, index=True)
    number = Column(Integer, nullable=False)  # 1-65535
    protocol = Column(String(10), default="tcp")  # tcp, udp
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    ip_address = relationship("IPAddress", back_populates="ports")
    services = relationship("Service", back_populates="port", cascade="all, delete-orphan")
