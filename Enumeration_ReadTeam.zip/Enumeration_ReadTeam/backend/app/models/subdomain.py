from sqlalchemy import Column, Integer, String, ForeignKey, Text, DateTime, Enum as SQLEnum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.session import Base
import enum


class SubdomainStatus(str, enum.Enum):
    UP = "up"
    DOWN = "down"
    UNKNOWN = "unknown"
    EXPLOITED = "exploited"


class Subdomain(Base):
    __tablename__ = "subdomains"

    id = Column(Integer, primary_key=True, index=True)
    domain_id = Column(Integer, ForeignKey("domains.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(512), nullable=False, index=True)  # e.g. www.example.com
    status = Column(SQLEnum(SubdomainStatus), default=SubdomainStatus.UNKNOWN)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    domain = relationship("Domain", back_populates="subdomains")
    ip_addresses = relationship("IPAddress", back_populates="subdomain", cascade="all, delete-orphan")
    users = relationship("User", back_populates="subdomain", cascade="all, delete-orphan")
    cves = relationship("CVE", back_populates="subdomain", cascade="all, delete-orphan")
    notes = relationship("Note", back_populates="subdomain", cascade="all, delete-orphan", foreign_keys="Note.subdomain_id")
