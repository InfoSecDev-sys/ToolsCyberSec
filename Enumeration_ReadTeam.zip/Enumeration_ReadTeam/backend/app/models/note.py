from sqlalchemy import Column, Integer, String, ForeignKey, Text, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.session import Base


class Note(Base):
    __tablename__ = "notes"

    id = Column(Integer, primary_key=True, index=True)
    content = Column(Text, nullable=False)
    # Notes can attach to subdomain or domain or project - use polymorphic or multiple FKs
    subdomain_id = Column(Integer, ForeignKey("subdomains.id", ondelete="CASCADE"), nullable=True, index=True)
    domain_id = Column(Integer, ForeignKey("domains.id", ondelete="CASCADE"), nullable=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True)
    tags = Column(String(512), default="")  # comma-separated: critical, exposed, juicy, pivot
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    subdomain = relationship("Subdomain", back_populates="notes", foreign_keys=[subdomain_id])
    domain = relationship("Domain", back_populates="note_entries", foreign_keys=[domain_id])
    project = relationship("Project", back_populates="notes", foreign_keys=[project_id])
