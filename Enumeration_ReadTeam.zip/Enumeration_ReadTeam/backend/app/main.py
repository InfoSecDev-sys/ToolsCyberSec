from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.db import init_db
from app.api import projects, domains, subdomains, ip_addresses, ports, services, users, credentials, cves, notes, icons, dashboard, graph, import_export, auth

app = FastAPI(
    title="ReconGraph",
    description="Cybersecurity Recon & Enumeration Management Platform",
    version="1.0.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(projects.router)
app.include_router(domains.router)
app.include_router(subdomains.router)
app.include_router(ip_addresses.router)
app.include_router(ports.router)
app.include_router(services.router)
app.include_router(users.router)
app.include_router(credentials.router)
app.include_router(cves.router)
app.include_router(notes.router)
app.include_router(icons.router)
app.include_router(dashboard.router)
app.include_router(graph.router)
app.include_router(import_export.router)
app.include_router(auth.router)


@app.on_event("startup")
def startup():
    init_db()


@app.get("/")
def root():
    return {"app": "ReconGraph", "docs": "/docs"}
