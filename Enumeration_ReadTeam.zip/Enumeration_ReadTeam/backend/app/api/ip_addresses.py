from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Domain, Subdomain, IPAddress
from app.schemas import IPAddressCreate, IPAddressUpdate, IPAddressResponse

router = APIRouter(prefix="/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips", tags=["ip_addresses"])


def _get_subdomain(project_id: int, domain_id: int, subdomain_id: int, db: Session) -> Subdomain:
    sub = db.query(Subdomain).filter(
        Subdomain.id == subdomain_id,
        Subdomain.domain_id == domain_id
    ).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    return sub


@router.get("", response_model=list[IPAddressResponse])
def list_ips(project_id: int, domain_id: int, subdomain_id: int, db: Session = Depends(get_db)):
    _get_subdomain(project_id, domain_id, subdomain_id, db)
    return db.query(IPAddress).filter(IPAddress.subdomain_id == subdomain_id).order_by(IPAddress.address).all()


@router.post("", response_model=IPAddressResponse)
def create_ip(project_id: int, domain_id: int, subdomain_id: int, ip: IPAddressCreate, db: Session = Depends(get_db)):
    _get_subdomain(project_id, domain_id, subdomain_id, db)
    if ip.subdomain_id != subdomain_id:
        raise HTTPException(status_code=400, detail="subdomain_id mismatch")
    from app.models.ip_address import OSType as ModelOSType
    os_t = ModelOSType(ip.os_type.value) if ip.os_type else ModelOSType.unknown
    obj = IPAddress(subdomain_id=ip.subdomain_id, address=ip.address, os_type=os_t, icon_id=ip.icon_id)
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@router.get("/{ip_id}", response_model=IPAddressResponse)
def get_ip(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, db: Session = Depends(get_db)):
    _get_subdomain(project_id, domain_id, subdomain_id, db)
    obj = db.query(IPAddress).filter(IPAddress.id == ip_id, IPAddress.subdomain_id == subdomain_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="IP not found")
    return obj


@router.patch("/{ip_id}", response_model=IPAddressResponse)
def update_ip(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, ip: IPAddressUpdate, db: Session = Depends(get_db)):
    obj = db.query(IPAddress).filter(IPAddress.id == ip_id, IPAddress.subdomain_id == subdomain_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="IP not found")
    if ip.address is not None:
        obj.address = ip.address
    if ip.os_type is not None:
        from app.models.ip_address import OSType as ModelOSType
        obj.os_type = ModelOSType(ip.os_type.value)
    if ip.icon_id is not None:
        obj.icon_id = ip.icon_id
    db.commit()
    db.refresh(obj)
    return obj


@router.delete("/{ip_id}", status_code=204)
def delete_ip(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, db: Session = Depends(get_db)):
    obj = db.query(IPAddress).filter(IPAddress.id == ip_id, IPAddress.subdomain_id == subdomain_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="IP not found")
    db.delete(obj)
    db.commit()
    return None
