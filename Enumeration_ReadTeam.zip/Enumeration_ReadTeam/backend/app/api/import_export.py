from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from fastapi.responses import HTMLResponse, StreamingResponse
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import (
    Project, Domain, Subdomain, IPAddress, Port, Service, User, CVE, Credential, Note,
)
from app.models.subdomain import SubdomainStatus
from app.models.service import ServiceStatus
from defusedxml import ElementTree as ET
import csv
import io
import json
from datetime import datetime
from typing import Optional

router = APIRouter(prefix="/projects/{project_id}", tags=["import_export"])

EXAMPLE_SUBDOMAINS = [
    ("www.example.com", SubdomainStatus.UP),
    ("api.example.com", SubdomainStatus.UP),
    ("mail.example.com", SubdomainStatus.UNKNOWN),
    ("ftp.example.com", SubdomainStatus.DOWN),
    ("admin.example.com", SubdomainStatus.UNKNOWN),
]


def _get_project(project_id: int, db: Session) -> Project:
    p = db.query(Project).filter(Project.id == project_id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Project not found")
    return p


@router.post("/seed")
def seed_example_domain(project_id: int, db: Session = Depends(get_db)):
    """Create one example domain with subdomains for testing."""
    proj = _get_project(project_id, db)
    existing = db.query(Domain).filter(Domain.project_id == project_id, Domain.name == "example.com").first()
    if existing:
        return {"message": "Example domain already exists", "domain_id": existing.id}
    dom = Domain(project_id=project_id, name="example.com", notes="Example domain for testing", in_scope=True)
    db.add(dom)
    db.commit()
    db.refresh(dom)
    for name, status in EXAMPLE_SUBDOMAINS:
        sub = Subdomain(domain_id=dom.id, name=name, status=status)
        db.add(sub)
    db.commit()
    return {"message": "Example domain and subdomains created", "domain_id": dom.id, "subdomains": len(EXAMPLE_SUBDOMAINS)}


def _export_json_full(project_id: int, db: Session):
    proj = _get_project(project_id, db)
    domains = db.query(Domain).filter(Domain.project_id == project_id).all()
    out = {
        "project": {"id": proj.id, "name": proj.name, "description": proj.description or ""},
        "exported_at": datetime.utcnow().isoformat() + "Z",
        "domains": [],
        "notes": [],
    }
    for d in domains:
        subdomains = db.query(Subdomain).filter(Subdomain.domain_id == d.id).all()
        dom_data = {
            "id": d.id, "name": d.name, "notes": d.notes or "", "in_scope": d.in_scope,
            "subdomains": [],
        }
        for sub in subdomains:
            ips = db.query(IPAddress).filter(IPAddress.subdomain_id == sub.id).all()
            sub_data = {
                "id": sub.id, "name": sub.name, "status": sub.status.value if sub.status else "unknown",
                "ip_addresses": [],
                "users": [],
                "cves": [],
            }
            for ip in ips:
                ports = db.query(Port).filter(Port.ip_id == ip.id).all()
                ip_data = {"id": ip.id, "address": ip.address, "os_type": ip.os_type.value if ip.os_type else "unknown", "ports": []}
                for port in ports:
                    services = db.query(Service).filter(Service.port_id == port.id).all()
                    port_data = {"id": port.id, "number": port.number, "protocol": port.protocol, "services": []}
                    for s in services:
                        port_data["services"].append({"id": s.id, "name": s.name, "version": s.version or "", "banner": s.banner or "", "status": (s.status.value if s.status else "active"), "notes": s.notes or ""})
                    ip_data["ports"].append(port_data)
                sub_data["ip_addresses"].append(ip_data)
            for u in db.query(User).filter(User.subdomain_id == sub.id).all():
                creds = db.query(Credential).filter(Credential.user_id == u.id).all()
                sub_data["users"].append({
                    "id": u.id, "username": u.username, "email": u.email or "", "notes": u.notes or "",
                    "credentials": [{"password": c.password or "", "hash_type": c.hash_type or "", "notes": c.notes or ""} for c in creds],
                })
            for c in db.query(CVE).filter(CVE.subdomain_id == sub.id).all():
                sub_data["cves"].append({"id": c.id, "cve_id": c.cve_id, "severity": c.severity or "", "description": c.description or "", "cvss": c.cvss or "", "notes": c.notes or ""})
            dom_data["subdomains"].append(sub_data)
        out["domains"].append(dom_data)
    for note in db.query(Note).filter(Note.project_id == project_id).all():
        out["notes"].append({
            "id": note.id, "content": note.content, "tags": note.tags or "",
            "project_id": note.project_id, "domain_id": note.domain_id, "subdomain_id": note.subdomain_id,
        })
    return out


@router.get("/export/json")
def export_json(project_id: int, db: Session = Depends(get_db)):
    return _export_json_full(project_id, db)


@router.get("/export/csv")
def export_csv(project_id: int, db: Session = Depends(get_db)):
    proj = _get_project(project_id, db)
    buf = io.StringIO()
    w = csv.writer(buf)
    # Header: type + all possible columns
    w.writerow(["type", "domain", "subdomain", "status", "ip", "os_type", "port", "protocol", "service", "service_version", "service_status", "service_notes", "username", "email", "user_notes", "password", "hash_type", "cred_notes", "cve_id", "cve_severity", "cve_description", "cve_cvss", "cve_notes", "note_scope", "note_content", "note_tags"])
    domains = db.query(Domain).filter(Domain.project_id == project_id).all()
    for d in domains:
        for sub in db.query(Subdomain).filter(Subdomain.domain_id == d.id).all():
            # Host/port/service rows
            ips = db.query(IPAddress).filter(IPAddress.subdomain_id == sub.id).all()
            for ip in ips:
                ports = db.query(Port).filter(Port.ip_id == ip.id).all()
                if ports:
                    for port in ports:
                        for svc in db.query(Service).filter(Service.port_id == port.id).all():
                            w.writerow(["host", d.name, sub.name, sub.status.value if sub.status else "", ip.address, ip.os_type.value if ip.os_type else "", port.number, port.protocol, svc.name, svc.version or "", svc.status.value if svc.status else "", svc.notes or "", "", "", "", "", "", "", "", "", "", "", "", "", ""])
                else:
                    w.writerow(["host", d.name, sub.name, sub.status.value if sub.status else "", ip.address, ip.os_type.value if ip.os_type else "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""])
            # Subdomains with no IPs
            if not ips:
                w.writerow(["host", d.name, sub.name, sub.status.value if sub.status else "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""])
            # User rows
            for u in db.query(User).filter(User.subdomain_id == sub.id).all():
                creds = db.query(Credential).filter(Credential.user_id == u.id).all()
                if creds:
                    for c in creds:
                        w.writerow(["user", d.name, sub.name, "", "", "", "", "", "", "", "", "", u.username, u.email or "", u.notes or "", c.password or "", c.hash_type or "", c.notes or "", "", "", "", "", "", "", "", ""])
                else:
                    w.writerow(["user", d.name, sub.name, "", "", "", "", "", "", "", "", "", u.username, u.email or "", u.notes or "", "", "", "", "", "", "", "", "", "", "", "", ""])
            # CVE rows
            for c in db.query(CVE).filter(CVE.subdomain_id == sub.id).all():
                w.writerow(["cve", d.name, sub.name, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", c.cve_id, c.severity or "", c.description or "", c.cvss or "", c.notes or "", "", "", ""])
    # Project notes
    for note in db.query(Note).filter(Note.project_id == project_id).all():
        scope = "project" if note.project_id else ("domain" if note.domain_id else "subdomain")
        w.writerow(["note", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", scope, note.content[:500] if note.content else "", note.tags or ""])
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=recongraph_{proj.name}_{datetime.utcnow().strftime('%Y%m%d')}.csv"})


@router.get("/export/html", response_class=HTMLResponse)
def export_html(project_id: int, db: Session = Depends(get_db)):
    proj = _get_project(project_id, db)
    data = _export_json_full(project_id, db)
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>ReconGraph - {proj.name}</title>
<style>body{{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:2em;}}
h1{{color:#58a6ff;}} h2{{color:#79c0ff;}} h3{{color:#8b949e;}}
table{{border-collapse:collapse;margin-bottom:2em;}}
td,th{{border:1px solid #30363d;padding:6px;text-align:left;}}
.status-up{{color:#3fb950;}} .status-down{{color:#f85149;}} .status-unknown{{color:#8b949e;}} .status-exploited{{color:#a371f7;}}
.note-block{{background:#161b22;padding:10px;margin:8px 0;border-radius:4px;}}</style></head><body>
<h1>ReconGraph Report: {proj.name}</h1>
<p>Exported: {data['exported_at']}</p>
"""
    for dom in data["domains"]:
        html += f"<h2>Domain: {dom['name']}</h2>"
        for sub in dom["subdomains"]:
            html += f"<h3>Subdomain: {sub['name']} <span class=\"status-{sub['status']}\">({sub['status']})</span></h3>"
            html += "<table><tr><th>IP</th><th>OS</th><th>Port</th><th>Service</th><th>Version</th><th>Status</th></tr>"
            for ip in sub.get("ip_addresses", []):
                for port in ip.get("ports", []):
                    for svc in port.get("services", []):
                        html += f"<tr><td>{ip['address']}</td><td>{ip.get('os_type','')}</td><td>{port['number']}/{port['protocol']}</td><td>{svc['name']}</td><td>{svc.get('version','')}</td><td>{svc.get('status','')}</td></tr>"
                if not ip.get("ports"):
                    html += f"<tr><td>{ip['address']}</td><td>{ip.get('os_type','')}</td><td>-</td><td>-</td><td>-</td><td>-</td></tr>"
            if not sub.get("ip_addresses"):
                html += "<tr><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr>"
            html += "</table>"
            if sub.get("users"):
                html += "<table><tr><th>User</th><th>Email</th><th>Credentials</th></tr>"
                for u in sub["users"]:
                    cred_str = "; ".join([f"pass:{c.get('password','')}" if c.get("password") else "" for c in u.get("credentials", [])]) or "-"
                    html += f"<tr><td>{u['username']}</td><td>{u.get('email','')}</td><td>{cred_str}</td></tr>"
                html += "</table>"
            if sub.get("cves"):
                html += "<table><tr><th>CVE</th><th>Severity</th><th>Description</th></tr>"
                for c in sub["cves"]:
                    desc = (c.get("description") or "")[:200]
                    html += f"<tr><td>{c['cve_id']}</td><td>{c.get('severity','')}</td><td>{desc}</td></tr>"
                html += "</table>"
    if data.get("notes"):
        html += "<h2>Notes</h2>"
        for n in data["notes"]:
            html += f"<div class=\"note-block\"><strong>{n.get('tags','')}</strong><br/>{n['content'][:1000]}</div>"
    html += "</body></html>"
    return HTMLResponse(html)


@router.post("/import/subdomains")
async def import_subdomains_text(
    project_id: int,
    domain_id: int = Query(...),
    default_status: str = Query("unknown"),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    _get_project(project_id, db)
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    content = (await file.read()).decode("utf-8", errors="ignore")
    lines = [line.strip() for line in content.splitlines() if line.strip()]
    status = SubdomainStatus.UNKNOWN
    if default_status.lower() == "up":
        status = SubdomainStatus.UP
    elif default_status.lower() == "down":
        status = SubdomainStatus.DOWN
    elif default_status.lower() == "exploited":
        status = SubdomainStatus.EXPLOITED
    created = 0
    for name in lines:
        if db.query(Subdomain).filter(Subdomain.domain_id == domain_id, Subdomain.name == name).first():
            continue
        sub = Subdomain(domain_id=domain_id, name=name, status=status)
        db.add(sub)
        created += 1
    db.commit()
    return {"imported": created, "total_lines": len(lines)}


@router.post("/import/nmap")
async def import_nmap_xml(
    project_id: int,
    domain_id: int = Query(...),
    subdomain_id: int = Query(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    _get_project(project_id, db)
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    raw = await file.read()
    root = ET.fromstring(raw)
    created_ips = 0
    created_ports = 0
    for host in root.iter("host"):
        addresses = [a for a in host.iter("address") if a.get("addrtype") in ("ipv4", "ipv6")]
        if not addresses:
            continue
        ip_addr = addresses[0].get("addr")
        if not ip_addr:
            continue
        ip_obj = db.query(IPAddress).filter(IPAddress.subdomain_id == subdomain_id, IPAddress.address == ip_addr).first()
        if not ip_obj:
            ip_obj = IPAddress(subdomain_id=subdomain_id, address=ip_addr)
            db.add(ip_obj)
            db.commit()
            db.refresh(ip_obj)
            created_ips += 1
        ports_elem = host.find("ports")
        if ports_elem is not None:
            for port_elem in ports_elem.findall("port"):
                proto = port_elem.get("protocol", "tcp")
                num = port_elem.get("port")
                if num is None:
                    continue
                try:
                    port_num = int(num)
                except ValueError:
                    continue
                if db.query(Port).filter(Port.ip_id == ip_obj.id, Port.number == port_num).first():
                    continue
                port_obj = Port(ip_id=ip_obj.id, number=port_num, protocol=proto)
                db.add(port_obj)
                db.commit()
                db.refresh(port_obj)
                created_ports += 1
                svc_elem = port_elem.find("service")
                if svc_elem is not None:
                    svc_name = svc_elem.get("name", "unknown") or "unknown"
                    svc_version = svc_elem.get("product", "") or ""
                    if svc_elem.get("version"):
                        svc_version = (svc_version + " " + svc_elem.get("version", "")).strip()
                    svc = Service(port_id=port_obj.id, name=svc_name, version=svc_version)
                    db.add(svc)
                    db.commit()
    return {"imported_ips": created_ips, "imported_ports": created_ports}


@router.post("/import/users")
async def import_users(
    project_id: int,
    domain_id: int = Query(...),
    subdomain_id: int = Query(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Import users from file. Format: one per line - username, or username:password, or username,email, or username,email,password"""
    _get_project(project_id, db)
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    content = (await file.read()).decode("utf-8", errors="ignore")
    lines = [line.strip() for line in content.splitlines() if line.strip()]
    created = 0
    for line in lines:
        # Parse: username | username:password | username,email | username,email,password
        username, email, password = "", "", ""
        if ":" in line and "," not in line:
            parts = line.split(":", 1)
            username = parts[0].strip()
            password = (parts[1].strip() if len(parts) > 1 else "")
        elif "," in line:
            parts = [p.strip() for p in line.split(",")]
            username = parts[0] if parts else ""
            email = parts[1] if len(parts) > 1 else ""
            password = parts[2] if len(parts) > 2 else ""
        else:
            username = line
        if not username:
            continue
        if db.query(User).filter(User.subdomain_id == subdomain_id, User.username == username).first():
            continue
        user = User(subdomain_id=subdomain_id, username=username, email=email)
        db.add(user)
        db.commit()
        db.refresh(user)
        created += 1
        if password:
            cred = Credential(user_id=user.id, password=password)
            db.add(cred)
            db.commit()
    return {"imported": created, "total_lines": len(lines)}
