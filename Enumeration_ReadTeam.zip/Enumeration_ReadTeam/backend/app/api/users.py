from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Domain, Subdomain, User
from app.schemas import UserCreate, UserUpdate, UserResponse

router = APIRouter(prefix="/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/users", tags=["users"])


def _get_subdomain(project_id: int, domain_id: int, subdomain_id: int, db: Session) -> Subdomain:
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    return sub


@router.get("", response_model=list[UserResponse])
def list_users(project_id: int, domain_id: int, subdomain_id: int, db: Session = Depends(get_db)):
    _get_subdomain(project_id, domain_id, subdomain_id, db)
    return db.query(User).filter(User.subdomain_id == subdomain_id).all()


@router.post("", response_model=UserResponse)
def create_user(project_id: int, domain_id: int, subdomain_id: int, u: UserCreate, db: Session = Depends(get_db)):
    _get_subdomain(project_id, domain_id, subdomain_id, db)
    if u.subdomain_id != subdomain_id:
        raise HTTPException(status_code=400, detail="subdomain_id mismatch")
    user = User(subdomain_id=u.subdomain_id, username=u.username, email=u.email or "", notes=u.notes or "")
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.get("/{user_id}", response_model=UserResponse)
def get_user(project_id: int, domain_id: int, subdomain_id: int, user_id: int, db: Session = Depends(get_db)):
    _get_subdomain(project_id, domain_id, subdomain_id, db)
    user = db.query(User).filter(User.id == user_id, User.subdomain_id == subdomain_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.patch("/{user_id}", response_model=UserResponse)
def update_user(project_id: int, domain_id: int, subdomain_id: int, user_id: int, u: UserUpdate, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id, User.subdomain_id == subdomain_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if u.username is not None:
        user.username = u.username
    if u.email is not None:
        user.email = u.email
    if u.notes is not None:
        user.notes = u.notes
    db.commit()
    db.refresh(user)
    return user


@router.delete("/{user_id}", status_code=204)
def delete_user(project_id: int, domain_id: int, subdomain_id: int, user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id, User.subdomain_id == subdomain_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()
    return None
