from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Project, Domain, Subdomain
from app.schemas import SubdomainCreate, SubdomainUpdate, SubdomainResponse

router = APIRouter(prefix="/projects/{project_id}/domains/{domain_id}/subdomains", tags=["subdomains"])


def _get_domain(project_id: int, domain_id: int, db: Session) -> Domain:
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    return dom


@router.get("", response_model=list[SubdomainResponse])
def list_subdomains(project_id: int, domain_id: int, db: Session = Depends(get_db)):
    _get_domain(project_id, domain_id, db)
    return db.query(Subdomain).filter(Subdomain.domain_id == domain_id).order_by(Subdomain.name).all()


@router.post("", response_model=SubdomainResponse)
def create_subdomain(project_id: int, domain_id: int, s: SubdomainCreate, db: Session = Depends(get_db)):
    _get_domain(project_id, domain_id, db)
    if s.domain_id != domain_id:
        raise HTTPException(status_code=400, detail="domain_id mismatch")
    from app.models.subdomain import SubdomainStatus as ModelStatus
    status = ModelStatus(s.status.value) if s.status else ModelStatus.unknown
    sub = Subdomain(domain_id=s.domain_id, name=s.name, status=status)
    db.add(sub)
    db.commit()
    db.refresh(sub)
    return sub


@router.get("/{subdomain_id}", response_model=SubdomainResponse)
def get_subdomain(project_id: int, domain_id: int, subdomain_id: int, db: Session = Depends(get_db)):
    _get_domain(project_id, domain_id, db)
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    return sub


@router.patch("/{subdomain_id}", response_model=SubdomainResponse)
def update_subdomain(project_id: int, domain_id: int, subdomain_id: int, s: SubdomainUpdate, db: Session = Depends(get_db)):
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    if s.name is not None:
        sub.name = s.name
    if s.status is not None:
        from app.models.subdomain import SubdomainStatus as ModelStatus
        sub.status = ModelStatus(s.status.value)
    db.commit()
    db.refresh(sub)
    return sub


@router.delete("/{subdomain_id}", status_code=204)
def delete_subdomain(project_id: int, domain_id: int, subdomain_id: int, db: Session = Depends(get_db)):
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    db.delete(sub)
    db.commit()
    return None
