from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Project, Domain
from app.schemas import DomainCreate, DomainUpdate, DomainResponse

router = APIRouter(prefix="/projects/{project_id}/domains", tags=["domains"])


def _get_project(project_id: int, db: Session) -> Project:
    p = db.query(Project).filter(Project.id == project_id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Project not found")
    return p


@router.get("", response_model=list[DomainResponse])
def list_domains(project_id: int, db: Session = Depends(get_db)):
    _get_project(project_id, db)
    return db.query(Domain).filter(Domain.project_id == project_id).order_by(Domain.name).all()


@router.post("", response_model=DomainResponse)
def create_domain(project_id: int, d: DomainCreate, db: Session = Depends(get_db)):
    _get_project(project_id, db)
    if d.project_id != project_id:
        raise HTTPException(status_code=400, detail="project_id mismatch")
    dom = Domain(project_id=d.project_id, name=d.name, notes=d.notes or "", in_scope=d.in_scope)
    db.add(dom)
    db.commit()
    db.refresh(dom)
    return dom


@router.get("/{domain_id}", response_model=DomainResponse)
def get_domain(project_id: int, domain_id: int, db: Session = Depends(get_db)):
    _get_project(project_id, db)
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    return dom


@router.patch("/{domain_id}", response_model=DomainResponse)
def update_domain(project_id: int, domain_id: int, d: DomainUpdate, db: Session = Depends(get_db)):
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    if d.name is not None:
        dom.name = d.name
    if d.notes is not None:
        dom.notes = d.notes
    if d.in_scope is not None:
        dom.in_scope = d.in_scope
    db.commit()
    db.refresh(dom)
    return dom


@router.delete("/{domain_id}", status_code=204)
def delete_domain(project_id: int, domain_id: int, db: Session = Depends(get_db)):
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    db.delete(dom)
    db.commit()
    return None
