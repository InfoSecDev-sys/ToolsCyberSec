from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Domain, Subdomain, IPAddress, Port, Service
from app.models.service import ServiceStatus
from app.schemas import PortCreate, PortUpdate, PortResponse
from app.schemas.port import BulkPortsCreate

router = APIRouter(tags=["ports"])


def _get_ip_chain(db: Session, project_id: int, domain_id: int, subdomain_id: int, ip_id: int) -> IPAddress:
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    ip = db.query(IPAddress).filter(IPAddress.id == ip_id, IPAddress.subdomain_id == subdomain_id).first()
    if not ip:
        raise HTTPException(status_code=404, detail="IP not found")
    return ip


# Nested under project/domain/subdomain/ip
@router.get("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports", response_model=list[PortResponse])
def list_ports(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, db: Session = Depends(get_db)):
    _get_ip_chain(db, project_id, domain_id, subdomain_id, ip_id)
    return db.query(Port).filter(Port.ip_id == ip_id).order_by(Port.number).all()


# Common port -> service name for auto-creation
PORT_SERVICE_MAP = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 80: "http", 110: "pop3",
    143: "imap", 443: "https", 445: "smb", 993: "imaps", 995: "pop3s",
    1433: "mssql", 3306: "mysql", 3389: "rdp", 5432: "postgres",
    5900: "vnc", 6379: "redis", 8080: "http-proxy", 8443: "https-alt",
}

@router.post("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports", response_model=PortResponse)
def create_port(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, p: PortCreate, db: Session = Depends(get_db)):
    _get_ip_chain(db, project_id, domain_id, subdomain_id, ip_id)
    if p.ip_id != ip_id:
        raise HTTPException(status_code=400, detail="ip_id mismatch")
    port = Port(ip_id=p.ip_id, number=p.number, protocol=p.protocol or "tcp")
    db.add(port)
    db.commit()
    db.refresh(port)
    return port


@router.post("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports/bulk")
def bulk_create_ports(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, body: BulkPortsCreate, db: Session = Depends(get_db)):
    _get_ip_chain(db, project_id, domain_id, subdomain_id, ip_id)
    parts = [x.strip() for x in body.ports.replace(",", " ").split() if x.strip()]
    created = 0
    protocol = (body.protocol or "tcp").lower()
    for part in parts:
        try:
            num = int(part)
        except ValueError:
            continue
        if num < 1 or num > 65535:
            continue
        if db.query(Port).filter(Port.ip_id == ip_id, Port.number == num).first():
            continue
        port = Port(ip_id=ip_id, number=num, protocol=protocol)
        db.add(port)
        db.commit()
        db.refresh(port)
        created += 1
        svc_name = body.default_service or PORT_SERVICE_MAP.get(num)
        if svc_name:
            svc = Service(port_id=port.id, name=svc_name, status=ServiceStatus.ACTIVE)
            db.add(svc)
            db.commit()
    return {"created": created, "total_requested": len(parts)}


@router.get("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports/{port_id}", response_model=PortResponse)
def get_port(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, port_id: int, db: Session = Depends(get_db)):
    _get_ip_chain(db, project_id, domain_id, subdomain_id, ip_id)
    port = db.query(Port).filter(Port.id == port_id, Port.ip_id == ip_id).first()
    if not port:
        raise HTTPException(status_code=404, detail="Port not found")
    return port


@router.patch("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports/{port_id}", response_model=PortResponse)
def update_port(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, port_id: int, p: PortUpdate, db: Session = Depends(get_db)):
    port = db.query(Port).filter(Port.id == port_id, Port.ip_id == ip_id).first()
    if not port:
        raise HTTPException(status_code=404, detail="Port not found")
    if p.number is not None:
        port.number = p.number
    if p.protocol is not None:
        port.protocol = p.protocol
    db.commit()
    db.refresh(port)
    return port


@router.delete("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports/{port_id}", status_code=204)
def delete_port(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, port_id: int, db: Session = Depends(get_db)):
    port = db.query(Port).filter(Port.id == port_id, Port.ip_id == ip_id).first()
    if not port:
        raise HTTPException(status_code=404, detail="Port not found")
    db.delete(port)
    db.commit()
    return None
