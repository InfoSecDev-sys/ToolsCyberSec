from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Domain, Subdomain, User, Credential
from app.schemas import CredentialCreate, CredentialUpdate, CredentialResponse

router = APIRouter(tags=["credentials"])


def _get_user_chain(db: Session, project_id: int, domain_id: int, subdomain_id: int, user_id: int) -> User:
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    user = db.query(User).filter(User.id == user_id, User.subdomain_id == subdomain_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.get("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/users/{user_id}/credentials", response_model=list[CredentialResponse])
def list_credentials(project_id: int, domain_id: int, subdomain_id: int, user_id: int, db: Session = Depends(get_db)):
    _get_user_chain(db, project_id, domain_id, subdomain_id, user_id)
    return db.query(Credential).filter(Credential.user_id == user_id).all()


@router.post("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/users/{user_id}/credentials", response_model=CredentialResponse)
def create_credential(project_id: int, domain_id: int, subdomain_id: int, user_id: int, c: CredentialCreate, db: Session = Depends(get_db)):
    _get_user_chain(db, project_id, domain_id, subdomain_id, user_id)
    if c.user_id != user_id:
        raise HTTPException(status_code=400, detail="user_id mismatch")
    cred = Credential(user_id=c.user_id, password=c.password or "", hash_type=c.hash_type or "", notes=c.notes or "")
    db.add(cred)
    db.commit()
    db.refresh(cred)
    return cred


@router.patch("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/users/{user_id}/credentials/{credential_id}", response_model=CredentialResponse)
def update_credential(project_id: int, domain_id: int, subdomain_id: int, user_id: int, credential_id: int, c: CredentialUpdate, db: Session = Depends(get_db)):
    cred = db.query(Credential).filter(Credential.id == credential_id, Credential.user_id == user_id).first()
    if not cred:
        raise HTTPException(status_code=404, detail="Credential not found")
    if c.password is not None:
        cred.password = c.password
    if c.hash_type is not None:
        cred.hash_type = c.hash_type
    if c.notes is not None:
        cred.notes = c.notes
    db.commit()
    db.refresh(cred)
    return cred


@router.delete("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/users/{user_id}/credentials/{credential_id}", status_code=204)
def delete_credential(project_id: int, domain_id: int, subdomain_id: int, user_id: int, credential_id: int, db: Session = Depends(get_db)):
    cred = db.query(Credential).filter(Credential.id == credential_id, Credential.user_id == user_id).first()
    if not cred:
        raise HTTPException(status_code=404, detail="Credential not found")
    db.delete(cred)
    db.commit()
    return None
