from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from app.db import get_db
from app.models import (
    Project, Domain, Subdomain, IPAddress, Port, Service, User, CVE,
)
from app.models.subdomain import SubdomainStatus
from app.models.service import ServiceStatus

router = APIRouter(prefix="/projects/{project_id}", tags=["graph"])


class GraphNode(BaseModel):
    id: str
    type: str  # project, domain, subdomain, ip, port, service, user, cve
    label: str
    status: Optional[str] = None
    data: Optional[dict] = None


class GraphEdge(BaseModel):
    id: str
    source: str
    target: str


class GraphResponse(BaseModel):
    nodes: list[GraphNode]
    edges: list[GraphEdge]


def _node_id(typ: str, pk: int) -> str:
    return f"{typ}_{pk}"


@router.get("/graph", response_model=GraphResponse)
def get_graph(
    project_id: int,
    alive_only: bool = Query(False, description="Show only alive subdomains"),
    vulnerable_only: bool = Query(False, description="Show only vulnerable/exploitable services"),
    db: Session = Depends(get_db),
):
    proj = db.query(Project).filter(Project.id == project_id).first()
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")

    nodes: list[GraphNode] = []
    edges: list[GraphEdge] = []

    pid = _node_id("project", proj.id)
    nodes.append(GraphNode(id=pid, type="project", label=proj.name, data={"project_id": proj.id}))

    domains = db.query(Domain).filter(Domain.project_id == project_id).all()
    for d in domains:
        did = _node_id("domain", d.id)
        nodes.append(GraphNode(id=did, type="domain", label=d.name, data={"domain_id": d.id, "copyText": d.name, "linkUrl": f"https://{d.name}"}))
        edges.append(GraphEdge(id=f"{pid}-{did}", source=pid, target=did))

        subdomains = db.query(Subdomain).filter(Subdomain.domain_id == d.id)
        if alive_only:
            subdomains = subdomains.filter(Subdomain.status == SubdomainStatus.UP)
        for sub in subdomains:
            sid = _node_id("subdomain", sub.id)
            status = sub.status.value if sub.status else "unknown"
            nodes.append(GraphNode(id=sid, type="subdomain", label=sub.name, status=status, data={"subdomain_id": sub.id, "copyText": sub.name, "linkUrl": f"https://{sub.name}"}))
            edges.append(GraphEdge(id=f"{did}-{sid}", source=did, target=sid))

            for ip in db.query(IPAddress).filter(IPAddress.subdomain_id == sub.id):
                iid = _node_id("ip", ip.id)
                os_type = ip.os_type.value if ip.os_type else "unknown"
                nodes.append(GraphNode(id=iid, type="ip", label=ip.address, data={"ip_id": ip.id, "os_type": os_type, "copyText": ip.address}))
                edges.append(GraphEdge(id=f"{sid}-{iid}", source=sid, target=iid))

                for port in db.query(Port).filter(Port.ip_id == ip.id):
                    port_id = _node_id("port", port.id)
                    nodes.append(GraphNode(id=port_id, type="port", label=f"{port.number}/{port.protocol}", data={"port_id": port.id}))
                    edges.append(GraphEdge(id=f"{iid}-{port_id}", source=iid, target=port_id))

                    for svc in db.query(Service).filter(Service.port_id == port.id):
                        if vulnerable_only and svc.status not in (ServiceStatus.VULNERABLE, ServiceStatus.EXPLOITABLE, ServiceStatus.EXPLOITED):
                            continue
                        svc_id = _node_id("service", svc.id)
                        nodes.append(GraphNode(id=svc_id, type="service", label=svc.name, status=(svc.status.value if svc.status else "active"), data={"service_id": svc.id}))
                        edges.append(GraphEdge(id=f"{port_id}-{svc_id}", source=port_id, target=svc_id))

            for u in db.query(User).filter(User.subdomain_id == sub.id):
                uid = _node_id("user", u.id)
                nodes.append(GraphNode(id=uid, type="user", label=u.username, data={"user_id": u.id}))
                edges.append(GraphEdge(id=f"{sid}-{uid}", source=sid, target=uid))

            for cve in db.query(CVE).filter(CVE.subdomain_id == sub.id):
                cid = _node_id("cve", cve.id)
                nodes.append(GraphNode(id=cid, type="cve", label=cve.cve_id, data={"cve_id": cve.id, "severity": cve.severity}))
                edges.append(GraphEdge(id=f"{sid}-{cid}", source=sid, target=cid))

    return GraphResponse(nodes=nodes, edges=edges)
