from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Domain, Subdomain, IPAddress, Port, Service
from app.schemas import ServiceCreate, ServiceUpdate, ServiceResponse

router = APIRouter(tags=["services"])


def _get_port_chain(db: Session, project_id: int, domain_id: int, subdomain_id: int, ip_id: int, port_id: int) -> Port:
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    ip = db.query(IPAddress).filter(IPAddress.id == ip_id, IPAddress.subdomain_id == subdomain_id).first()
    if not ip:
        raise HTTPException(status_code=404, detail="IP not found")
    port = db.query(Port).filter(Port.id == port_id, Port.ip_id == ip_id).first()
    if not port:
        raise HTTPException(status_code=404, detail="Port not found")
    return port


@router.get("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports/{port_id}/services", response_model=list[ServiceResponse])
def list_services(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, port_id: int, db: Session = Depends(get_db)):
    _get_port_chain(db, project_id, domain_id, subdomain_id, ip_id, port_id)
    return db.query(Service).filter(Service.port_id == port_id).all()


@router.post("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports/{port_id}/services", response_model=ServiceResponse)
def create_service(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, port_id: int, s: ServiceCreate, db: Session = Depends(get_db)):
    _get_port_chain(db, project_id, domain_id, subdomain_id, ip_id, port_id)
    if s.port_id != port_id:
        raise HTTPException(status_code=400, detail="port_id mismatch")
    from app.models.service import ServiceStatus as ModelStatus
    status = ModelStatus(s.status.value) if s.status else ModelStatus.active
    svc = Service(port_id=s.port_id, name=s.name, version=s.version or "", banner=s.banner or "", status=status, notes=s.notes or "")
    db.add(svc)
    db.commit()
    db.refresh(svc)
    return svc


@router.get("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports/{port_id}/services/{service_id}", response_model=ServiceResponse)
def get_service(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, port_id: int, service_id: int, db: Session = Depends(get_db)):
    _get_port_chain(db, project_id, domain_id, subdomain_id, ip_id, port_id)
    svc = db.query(Service).filter(Service.id == service_id, Service.port_id == port_id).first()
    if not svc:
        raise HTTPException(status_code=404, detail="Service not found")
    return svc


@router.patch("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports/{port_id}/services/{service_id}", response_model=ServiceResponse)
def update_service(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, port_id: int, service_id: int, s: ServiceUpdate, db: Session = Depends(get_db)):
    svc = db.query(Service).filter(Service.id == service_id, Service.port_id == port_id).first()
    if not svc:
        raise HTTPException(status_code=404, detail="Service not found")
    if s.name is not None:
        svc.name = s.name
    if s.version is not None:
        svc.version = s.version
    if s.banner is not None:
        svc.banner = s.banner
    if s.status is not None:
        from app.models.service import ServiceStatus as ModelStatus
        svc.status = ModelStatus(s.status.value)
    if s.notes is not None:
        svc.notes = s.notes
    db.commit()
    db.refresh(svc)
    return svc


@router.delete("/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/ips/{ip_id}/ports/{port_id}/services/{service_id}", status_code=204)
def delete_service(project_id: int, domain_id: int, subdomain_id: int, ip_id: int, port_id: int, service_id: int, db: Session = Depends(get_db)):
    svc = db.query(Service).filter(Service.id == service_id, Service.port_id == port_id).first()
    if not svc:
        raise HTTPException(status_code=404, detail="Service not found")
    db.delete(svc)
    db.commit()
    return None
