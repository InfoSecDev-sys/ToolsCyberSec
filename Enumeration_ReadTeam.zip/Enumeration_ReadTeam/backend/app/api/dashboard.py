from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import (
    Project, Domain, Subdomain, IPAddress, Port, Service, CVE,
)
from app.models.subdomain import SubdomainStatus
from app.models.service import ServiceStatus
from app.schemas import DashboardStats

router = APIRouter(prefix="/projects/{project_id}", tags=["dashboard"])


@router.get("/dashboard", response_model=DashboardStats)
def get_dashboard(project_id: int, db: Session = Depends(get_db)):
    proj = db.query(Project).filter(Project.id == project_id).first()
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")

    domains = db.query(Domain).filter(Domain.project_id == project_id).all()
    domain_ids = [d.id for d in domains]
    total_domains = len(domains)

    if not domain_ids:
        return DashboardStats(
            total_domains=0,
            total_subdomains=0,
            alive_subdomains=0,
            dead_subdomains=0,
            total_ips=0,
            total_ports=0,
            total_services=0,
            total_vulnerabilities=0,
            exploited_services=0,
            recon_progress_pct=0.0,
            enumeration_progress_pct=0.0,
            exploitation_progress_pct=0.0,
        )

    subdomains_q = db.query(Subdomain).filter(Subdomain.domain_id.in_(domain_ids))
    subdomains_list = subdomains_q.all()
    total_subdomains = len(subdomains_list)
    alive_subdomains = sum(1 for s in subdomains_list if s.status == SubdomainStatus.UP)
    dead_subdomains = sum(1 for s in subdomains_list if s.status == SubdomainStatus.DOWN)
    subdomain_ids = [s.id for s in subdomains_list]

    total_ips = db.query(IPAddress).filter(IPAddress.subdomain_id.in_(subdomain_ids)).count() if subdomain_ids else 0
    total_ports = db.query(Port).join(IPAddress).filter(IPAddress.subdomain_id.in_(subdomain_ids)).count() if subdomain_ids else 0
    total_services = db.query(Service).join(Port).join(IPAddress).filter(IPAddress.subdomain_id.in_(subdomain_ids)).count() if subdomain_ids else 0
    total_vulnerabilities = db.query(CVE).filter(CVE.subdomain_id.in_(subdomain_ids)).count() if subdomain_ids else 0
    exploited_services = db.query(Service).join(Port).join(IPAddress).filter(
        IPAddress.subdomain_id.in_(subdomain_ids),
        Service.status == ServiceStatus.EXPLOITED,
    ).count() if subdomain_ids else 0

    # Progress heuristics: recon = subdomains discovered, enum = IPs+ports+services, exploit = exploited count
    recon_pct = min(100.0, (alive_subdomains / max(1, total_subdomains)) * 100.0) if total_subdomains else 0.0
    enum_pct = min(100.0, (total_ports + total_services) / max(1, total_ips * 2) * 100.0) if total_ips else 0.0
    exploit_pct = (exploited_services / max(1, total_services)) * 100.0 if total_services else 0.0

    return DashboardStats(
        total_domains=total_domains,
        total_subdomains=total_subdomains,
        alive_subdomains=alive_subdomains,
        dead_subdomains=dead_subdomains,
        total_ips=total_ips,
        total_ports=total_ports,
        total_services=total_services,
        total_vulnerabilities=total_vulnerabilities,
        exploited_services=exploited_services,
        recon_progress_pct=round(recon_pct, 1),
        enumeration_progress_pct=round(enum_pct, 1),
        exploitation_progress_pct=round(exploit_pct, 1),
    )
