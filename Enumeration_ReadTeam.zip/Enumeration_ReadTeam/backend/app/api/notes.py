from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Project, Note
from app.schemas import NoteCreate, NoteUpdate, NoteResponse

router = APIRouter(tags=["notes"])


@router.get("/projects/{project_id}/notes", response_model=list[NoteResponse])
def list_notes(
    project_id: int,
    domain_id: int | None = Query(None),
    subdomain_id: int | None = Query(None),
    db: Session = Depends(get_db),
):
    proj = db.query(Project).filter(Project.id == project_id).first()
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")
    q = db.query(Note).filter(Note.project_id == project_id)
    if domain_id is not None:
        q = q.filter(Note.domain_id == domain_id)
    if subdomain_id is not None:
        q = q.filter(Note.subdomain_id == subdomain_id)
    return q.order_by(Note.id.desc()).all()


@router.post("/projects/{project_id}/notes", response_model=NoteResponse)
def create_note(project_id: int, n: NoteCreate, db: Session = Depends(get_db)):
    proj = db.query(Project).filter(Project.id == project_id).first()
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")
    note = Note(
        content=n.content,
        tags=n.tags or "",
        project_id=project_id,
        domain_id=n.domain_id,
        subdomain_id=n.subdomain_id,
    )
    db.add(note)
    db.commit()
    db.refresh(note)
    return note


@router.get("/projects/{project_id}/notes/{note_id}", response_model=NoteResponse)
def get_note(project_id: int, note_id: int, db: Session = Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id, Note.project_id == project_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    return note


@router.patch("/projects/{project_id}/notes/{note_id}", response_model=NoteResponse)
def update_note(project_id: int, note_id: int, n: NoteUpdate, db: Session = Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id, Note.project_id == project_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    if n.content is not None:
        note.content = n.content
    if n.tags is not None:
        note.tags = n.tags
    if n.domain_id is not None:
        note.domain_id = n.domain_id
    if n.subdomain_id is not None:
        note.subdomain_id = n.subdomain_id
    db.commit()
    db.refresh(note)
    return note


@router.delete("/projects/{project_id}/notes/{note_id}", status_code=204)
def delete_note(project_id: int, note_id: int, db: Session = Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id, Note.project_id == project_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    db.delete(note)
    db.commit()
    return None
