from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from pathlib import Path
import uuid
from app.db import get_db
from app.models import Icon
from app.schemas import IconCreate, IconResponse
from app.core.config import settings

router = APIRouter(prefix="/icons", tags=["icons"])

ICONS_DIR = settings.upload_dir / "icons"
ICONS_DIR.mkdir(parents=True, exist_ok=True)


@router.get("", response_model=list[IconResponse])
def list_icons(db: Session = Depends(get_db)):
    return db.query(Icon).order_by(Icon.name).all()


@router.post("", response_model=IconResponse)
def create_icon(data: IconCreate | None = None, db: Session = Depends(get_db)):
    if data:
        icon = Icon(name=data.name, os_type=data.os_type or "", file_path=data.file_path or "", data_url=data.data_url or "")
    else:
        icon = Icon(name="", os_type="", file_path="", data_url="")
    db.add(icon)
    db.commit()
    db.refresh(icon)
    return icon


@router.post("/upload", response_model=IconResponse)
async def upload_icon(
    file: UploadFile = File(...),
    name: str = "",
    os_type: str = "",
    db: Session = Depends(get_db),
):
    ext = Path(file.filename or "icon").suffix or ".png"
    safe_name = f"{uuid.uuid4().hex}{ext}"
    path = ICONS_DIR / safe_name
    content = await file.read()
    path.write_bytes(content)
    rel_path = f"icons/{safe_name}"
    icon = Icon(name=name or file.filename or "Icon", os_type=os_type, file_path=rel_path)
    db.add(icon)
    db.commit()
    db.refresh(icon)
    return icon


@router.get("/{icon_id}", response_model=IconResponse)
def get_icon(icon_id: int, db: Session = Depends(get_db)):
    icon = db.query(Icon).filter(Icon.id == icon_id).first()
    if not icon:
        raise HTTPException(status_code=404, detail="Icon not found")
    return icon


@router.delete("/{icon_id}", status_code=204)
def delete_icon(icon_id: int, db: Session = Depends(get_db)):
    icon = db.query(Icon).filter(Icon.id == icon_id).first()
    if not icon:
        raise HTTPException(status_code=404, detail="Icon not found")
    if icon.file_path:
        full = settings.upload_dir / icon.file_path
        if full.exists():
            full.unlink()
    db.delete(icon)
    db.commit()
    return None
