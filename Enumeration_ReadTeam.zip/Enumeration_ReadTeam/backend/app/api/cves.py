from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Domain, Subdomain, CVE
from app.schemas import CVECreate, CVEUpdate, CVEResponse

router = APIRouter(prefix="/projects/{project_id}/domains/{domain_id}/subdomains/{subdomain_id}/cves", tags=["cves"])


def _get_subdomain(project_id: int, domain_id: int, subdomain_id: int, db: Session) -> Subdomain:
    dom = db.query(Domain).filter(Domain.id == domain_id, Domain.project_id == project_id).first()
    if not dom:
        raise HTTPException(status_code=404, detail="Domain not found")
    sub = db.query(Subdomain).filter(Subdomain.id == subdomain_id, Subdomain.domain_id == domain_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subdomain not found")
    return sub


@router.get("", response_model=list[CVEResponse])
def list_cves(project_id: int, domain_id: int, subdomain_id: int, db: Session = Depends(get_db)):
    _get_subdomain(project_id, domain_id, subdomain_id, db)
    return db.query(CVE).filter(CVE.subdomain_id == subdomain_id).all()


@router.post("", response_model=CVEResponse)
def create_cve(project_id: int, domain_id: int, subdomain_id: int, c: CVECreate, db: Session = Depends(get_db)):
    _get_subdomain(project_id, domain_id, subdomain_id, db)
    if c.subdomain_id != subdomain_id:
        raise HTTPException(status_code=400, detail="subdomain_id mismatch")
    cve = CVE(subdomain_id=c.subdomain_id, cve_id=c.cve_id, description=c.description or "", severity=c.severity or "", cvss=c.cvss or "", notes=c.notes or "")
    db.add(cve)
    db.commit()
    db.refresh(cve)
    return cve


@router.get("/{cve_id}", response_model=CVEResponse)
def get_cve(project_id: int, domain_id: int, subdomain_id: int, cve_id: int, db: Session = Depends(get_db)):
    _get_subdomain(project_id, domain_id, subdomain_id, db)
    cve = db.query(CVE).filter(CVE.id == cve_id, CVE.subdomain_id == subdomain_id).first()
    if not cve:
        raise HTTPException(status_code=404, detail="CVE not found")
    return cve


@router.patch("/{cve_id}", response_model=CVEResponse)
def update_cve(project_id: int, domain_id: int, subdomain_id: int, cve_id: int, c: CVEUpdate, db: Session = Depends(get_db)):
    cve = db.query(CVE).filter(CVE.id == cve_id, CVE.subdomain_id == subdomain_id).first()
    if not cve:
        raise HTTPException(status_code=404, detail="CVE not found")
    if c.cve_id is not None:
        cve.cve_id = c.cve_id
    if c.description is not None:
        cve.description = c.description
    if c.severity is not None:
        cve.severity = c.severity
    if c.cvss is not None:
        cve.cvss = c.cvss
    if c.notes is not None:
        cve.notes = c.notes
    db.commit()
    db.refresh(cve)
    return cve


@router.delete("/{cve_id}", status_code=204)
def delete_cve(project_id: int, domain_id: int, subdomain_id: int, cve_id: int, db: Session = Depends(get_db)):
    cve = db.query(CVE).filter(CVE.id == cve_id, CVE.subdomain_id == subdomain_id).first()
    if not cve:
        raise HTTPException(status_code=404, detail="CVE not found")
    db.delete(cve)
    db.commit()
    return None
