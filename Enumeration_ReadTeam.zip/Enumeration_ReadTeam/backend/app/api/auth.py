from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.core.config import settings

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginBody(BaseModel):
    password: str


class LoginResponse(BaseModel):
    token: str
    message: str = "ok"


# Simple static token when password is set (local use only)
STATIC_TOKEN = "recongraph-local-token"


@router.get("/check")
def auth_check():
    """Returns whether password protection is enabled."""
    return {"protected": bool(settings.app_password)}


@router.post("/login", response_model=LoginResponse)
def login(body: LoginBody):
    """Login with password. Only used when APP_PASSWORD is set."""
    if not settings.app_password:
        return LoginResponse(token=STATIC_TOKEN, message="No password set")
    if body.password != settings.app_password:
        raise HTTPException(status_code=401, detail="Invalid password")
    return LoginResponse(token=STATIC_TOKEN)
