from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "ReconGraph"
    debug: bool = True
    data_dir: Path = Path(__file__).resolve().parent.parent.parent / "data"
    upload_dir: Path = Path(__file__).resolve().parent.parent.parent / "uploads"
    app_password: Optional[str] = None  # if set, login required (local only)

    @property
    def database_url(self) -> str:
        path = (self.data_dir / "recongraph.db").as_posix()
        return f"sqlite:///{path}"

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
settings.data_dir.mkdir(parents=True, exist_ok=True)
settings.upload_dir.mkdir(parents=True, exist_ok=True)
