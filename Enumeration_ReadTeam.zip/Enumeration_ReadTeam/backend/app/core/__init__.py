# Core config
